import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Dashboard } from './components/Dashboard';
import { SessionSetup } from './components/SessionSetup';
import { LiveInterviewRoom } from './components/LiveInterviewRoom';
import { SessionSummary } from './components/SessionSummary';
import { CollaborativeStudio } from './components/CollaborativeStudio';
import { PredictiveAnalytics } from './components/PredictiveAnalytics';
import { HistoryList } from './components/HistoryList';
import { WeaknessDetector } from './components/WeaknessDetector';
import { GroupDiscussionRoom } from './components/GroupDiscussionRoom';

const MainContent: React.FC = () => {
  const { currentTab } = useApp();

  return (
    <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
      {currentTab === 'dashboard' && <Dashboard />}
      {currentTab === 'setup' && <SessionSetup />}
      {currentTab === 'room' && <LiveInterviewRoom />}
      {currentTab === 'summary' && <SessionSummary />}
      {currentTab === 'weaknesses' && <WeaknessDetector />}
      {currentTab === 'gd-room' && <GroupDiscussionRoom />}
      {currentTab === 'collaborative' && <CollaborativeStudio />}
      {currentTab === 'analytics' && <PredictiveAnalytics />}
      {currentTab === 'history' && <HistoryList />}
    </main>
  );
};

export default function App() {
  return (
    <AppProvider>
      <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors font-sans antialiased">
        <Navbar />
        <MainContent />
        <footer className="border-t border-sky-100 dark:border-slate-800 py-6 text-center text-xs text-slate-500 dark:text-slate-400 bg-white/70 dark:bg-slate-900/50 backdrop-blur-xs">
          <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              PrepVertex AI • Idevify Solutions Project
            </span>
            <div className="flex items-center gap-4">
              <span className="text-lime-700 dark:text-lime-400 font-medium">AES-256 E2E Encrypted</span>
              <span>•</span>
              <span className="text-sky-600 dark:text-sky-400 font-medium">GD Arena & Weakness Detector Active</span>
            </div>
          </div>
        </footer>
      </div>
    </AppProvider>
  );
}
