export type Difficulty = 'Easy' | 'Medium' | 'Hard';

export type CategoryFocus = 'All-Round' | 'Technical Architecture' | 'Behavioral (STAR)' | 'System Design' | 'Problem Solving';

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: string;
  targetRole: string;
  createdAt: string;
  password?: string;
  isLoggedIn?: boolean;
}

export interface InterviewQuestion {
  id: number;
  question: string;
  type: 'technical' | 'behavioral' | 'system-design' | 'project-deep-dive';
  contextSnippet?: string;
  expectedKeyPoints: string[];
  hint: string;
}

export interface KeyCompetencyScores {
  technicalDepth: number;
  communication: number;
  problemSolving: number;
  relevance: number;
}

export interface AnswerFeedback {
  score: number; // 1-10
  strengths: string[];
  missingAreas: string[];
  idealAnswerModel: string;
  keyCompetencyScores: KeyCompetencyScores;
  feedbackSummary: string;
  source?: string;
  timestamp: string;
}

export interface QuestionSessionItem {
  question: InterviewQuestion;
  userAnswer: string;
  feedback?: AnswerFeedback;
  timeSpentSeconds: number;
  peerNotes?: string;
  audioRecorded?: boolean;
}

export interface InterviewSession {
  id: string;
  userId: string;
  targetRole: string;
  difficulty: Difficulty;
  categoryFocus: CategoryFocus;
  questionCount: number;
  questions: QuestionSessionItem[];
  overallScore: number;
  overallSummary: string;
  completedAt: string;
  timerPerQuestion: number; // 0 for untimed, else seconds (60, 90, 120)
  isEncrypted?: boolean;
  interviewerPersona: string;
  wasStoppedEarly?: boolean;
}

export interface PeerComment {
  id: string;
  author: string;
  role: string;
  avatar: string;
  text: string;
  timestamp: string;
  type: 'suggestion' | 'praise' | 'critique';
}

export interface SkillPriority {
  skill: string;
  urgency: 'CRITICAL' | 'HIGH' | 'MODERATE' | 'LOW';
  impactScore: string;
  actionItem: string;
}

export interface PredictiveAnalyticsData {
  hiringProbability: number;
  avgScore: number;
  totalSessions: number;
  skillPrioritization: SkillPriority[];
  cohortBenchmark: {
    userPercentile: number;
    cohortAverageScore: number;
    topTenPercentScore: number;
    readinessLevel: string;
  };
  targetRole: string;
}

export interface InterviewerPersona {
  id: string;
  name: string;
  title: string;
  company: string;
  avatar: string;
  voicePitch: number;
  voiceRate: number;
  tagline: string;
}

// 14. Weakness Detector Types
export interface WeaknessTopic {
  id: string;
  topic: string;
  category: 'System Architecture' | 'Algorithms & Data Structures' | 'Behavioral & Leadership' | 'Database & Storage' | 'DevOps & Reliability' | 'Frontend Performance';
  severity: 'Critical' | 'High' | 'Moderate';
  frequencyDetected: number;
  diagnosis: string;
  suggestedAction: string;
  recoveryProgress: number; // 0 - 100%
  sampleQuestionPrompt: string;
  lastTestedDate?: string;
}

// Group Discussion (GD) Arena Types
export interface GDParticipant {
  id: string;
  name: string;
  avatar: string;
  role: string;
  isSpeaking: boolean;
  isMuted: boolean;
  hasRaisedHand: boolean;
  speakingTimeSec: number;
  isAI?: boolean;
  colorRing?: string;
}

export interface GDMessage {
  id: string;
  senderId: string;
  senderName: string;
  avatar: string;
  text: string;
  timestamp: string;
  type?: 'speech' | 'chat' | 'moderator';
}

export interface GDRoom {
  id: string;
  title: string;
  topicDescription: string;
  category: string;
  moderatorName: string;
  activeSpeakersCount: number;
  participants: GDParticipant[];
  callDurationSec: number;
  isCallActive: boolean;
  inviteCode: string;
}

export interface GDScorecard {
  leadershipScore: number; // 1-10
  clarityScore: number;
  listeningEtiquette: number;
  knowledgeScore: number;
  totalScore: number;
  feedback: string;
  keyPointsSpoken: string[];
  improvements: string[];
}
