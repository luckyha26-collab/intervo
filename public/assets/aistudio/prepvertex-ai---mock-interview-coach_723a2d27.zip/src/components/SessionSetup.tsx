import React, { useState } from 'react';
import {
  Sliders,
  Play,
  Clock,
  Briefcase,
  Layers,
  Sparkles,
  RefreshCw,
  AlertCircle
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Difficulty, CategoryFocus } from '../types';
import { INTERVIEWER_PERSONAS } from '../utils/speechEngine';
import { ResumeUpload } from './ResumeUpload';

export const SessionSetup: React.FC = () => {
  const { currentResume, startSession, isGeneratingQuestions, evaluationError } = useApp();

  const [targetRole, setTargetRole] = useState(currentResume.roleTarget || 'Frontend Developer');
  const [difficulty, setDifficulty] = useState<Difficulty>('Medium');
  const [questionCount, setQuestionCount] = useState<number>(5);
  const [categoryFocus, setCategoryFocus] = useState<CategoryFocus>('All-Round');
  const [timerPerQuestion, setTimerPerQuestion] = useState<number>(90);
  const [selectedPersonaId, setSelectedPersonaId] = useState<string>('sarah');

  const popularRoles = [
    'Frontend Developer',
    'Full Stack Engineer',
    'Backend Engineer',
    'Machine Learning Engineer',
    'DevOps / SRE',
    'Product Manager'
  ];

  const handleStart = async () => {
    await startSession({
      targetRole,
      difficulty,
      categoryFocus,
      questionCount,
      timerPerQuestion,
      personaId: selectedPersonaId
    });
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-12 animate-fade-in">
      {/* Top Heading */}
      <div className="text-center max-w-2xl mx-auto space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 text-xs font-bold border border-sky-200">
          <Sparkles className="w-3.5 h-3.5 text-lime-600" />
          Idevify AI Mock Interview Coach Pro
        </div>
        <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900 dark:text-white">
          Configure Your Tailored Mock Interview
        </h2>
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
          AI inspects your resume projects and tech stack to ask targeted, role-specific questions with real-time audio and instant scoring.
        </p>
      </div>

      {/* Step 1: Resume Upload & Extraction */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-sky-100 dark:border-slate-800 p-6 sm:p-8 shadow-xs">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex items-center justify-center w-7 h-7 rounded-xl bg-sky-500 text-white font-extrabold text-xs">
            1
          </div>
          <div>
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
              Resume Analysis & Skill Context
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Upload your resume or pick a curated sample profile below
            </p>
          </div>
        </div>

        <ResumeUpload />
      </div>

      {/* Step 2: Session Parameters */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-sky-100 dark:border-slate-800 p-6 sm:p-8 shadow-xs space-y-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex items-center justify-center w-7 h-7 rounded-xl bg-lime-600 text-white font-extrabold text-xs">
            2
          </div>
          <div>
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
              Session Settings & Difficulty Level
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Customize the interview scope, time constraints, and interviewer persona
            </p>
          </div>
        </div>

        {/* Target Job Role */}
        <div className="space-y-3">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
            <Briefcase className="w-4 h-4 text-sky-500" />
            Target Job Role (Tailors Question Domain)
          </label>
          <input
            type="text"
            value={targetRole}
            onChange={(e) => setTargetRole(e.target.value)}
            className="w-full px-4 py-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm font-semibold focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
            placeholder="e.g. Senior Frontend Engineer, SRE, ML Engineer..."
          />
          <div className="flex flex-wrap gap-2 pt-1">
            {popularRoles.map((role) => (
              <button
                key={role}
                type="button"
                onClick={() => setTargetRole(role)}
                className={`text-xs px-3 py-1.5 rounded-xl border transition-all ${
                  targetRole === role
                    ? 'border-sky-500 bg-sky-50 text-sky-800 dark:bg-sky-950/60 dark:text-sky-300 font-bold'
                    : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                {role}
              </button>
            ))}
          </div>
        </div>

        {/* Difficulty Level & Question Count */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* Difficulty Cards */}
          <div className="space-y-3">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-sky-500" />
              Difficulty Level
            </label>
            <div className="grid grid-cols-3 gap-2.5">
              {[
                { level: 'Easy', label: 'Easy', desc: 'Fresher / Fundamentals', color: 'border-lime-500 text-lime-800 bg-lime-50/50' },
                { level: 'Medium', label: 'Medium', desc: 'Mid-level / Trade-offs', color: 'border-sky-500 text-sky-800 bg-sky-50/50' },
                { level: 'Hard', label: 'Hard', desc: 'Senior / Edge cases', color: 'border-rose-400 text-rose-800 bg-rose-50/50' },
              ].map((item) => {
                const isSelected = difficulty === item.level;
                return (
                  <button
                    key={item.level}
                    type="button"
                    onClick={() => setDifficulty(item.level as Difficulty)}
                    className={`p-3.5 rounded-2xl border text-center transition-all ${
                      isSelected
                        ? `ring-2 ring-sky-500 dark:ring-sky-400 ${item.color} font-bold shadow-xs`
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <div className="text-sm font-bold">{item.label}</div>
                    <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5 leading-tight">{item.desc}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Number of Questions */}
          <div className="space-y-3">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
              <Layers className="w-4 h-4 text-sky-500" />
              Number of Questions
            </label>
            <div className="grid grid-cols-3 gap-2.5">
              {[
                { count: 3, label: '3 Questions', desc: 'Quick Sprint (~8 min)' },
                { count: 5, label: '5 Questions', desc: 'Standard Round (~15 min)' },
                { count: 8, label: '8 Questions', desc: 'Full Deep Dive (~25 min)' }
              ].map((item) => {
                const isSelected = questionCount === item.count;
                return (
                  <button
                    key={item.count}
                    type="button"
                    onClick={() => setQuestionCount(item.count)}
                    className={`p-3.5 rounded-2xl border text-center transition-all ${
                      isSelected
                        ? 'border-sky-500 bg-sky-50 text-sky-800 dark:bg-sky-950/60 dark:text-sky-300 font-bold ring-2 ring-sky-400 shadow-xs'
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <div className="text-sm font-bold">{item.label}</div>
                    <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">{item.desc}</div>
                  </button>
                );
              })}
            </div>
          </div>

        </div>

        {/* Category Focus & Per-Question Timer */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
          
          {/* Category Focus */}
          <div className="space-y-3">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
              Evaluation Category Focus
            </label>
            <select
              value={categoryFocus}
              onChange={(e) => setCategoryFocus(e.target.value as CategoryFocus)}
              className="w-full px-4 py-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm font-semibold focus:ring-2 focus:ring-sky-500"
            >
              <option value="All-Round">All-Round (Balanced Technical & Behavioral)</option>
              <option value="Technical Architecture">Technical Architecture & Stack Mastery</option>
              <option value="Behavioral (STAR)">Behavioral Leadership (STAR Method)</option>
              <option value="System Design">System Design & Scalability</option>
              <option value="Problem Solving">Problem Solving & Debugging</option>
            </select>
          </div>

          {/* Per-Question Timer */}
          <div className="space-y-3">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
              <Clock className="w-4 h-4 text-sky-500" />
              Per-Question Countdown Timer
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { sec: 60, label: '60s' },
                { sec: 90, label: '90s' },
                { sec: 120, label: '120s' },
                { sec: 0, label: 'Untimed' }
              ].map((item) => {
                const isSelected = timerPerQuestion === item.sec;
                return (
                  <button
                    key={item.sec}
                    type="button"
                    onClick={() => setTimerPerQuestion(item.sec)}
                    className={`py-2.5 px-2 rounded-xl border text-center text-xs font-bold transition-all ${
                      isSelected
                        ? 'border-sky-500 bg-sky-50 text-sky-800 dark:bg-sky-950/60 dark:text-sky-300 ring-2 ring-sky-400 shadow-xs'
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {item.label}
                  </button>
                );
              })}
            </div>
          </div>

        </div>

        {/* Interviewer Persona Selection */}
        <div className="space-y-3 pt-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
            Select Interviewer Persona & Voice
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {INTERVIEWER_PERSONAS.map((persona) => {
              const isSelected = selectedPersonaId === persona.id;
              return (
                <div
                  key={persona.id}
                  onClick={() => setSelectedPersonaId(persona.id)}
                  className={`flex items-center gap-3 p-3.5 rounded-2xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'border-sky-500 bg-sky-50/70 dark:bg-sky-950/40 ring-2 ring-sky-400'
                      : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <img
                    src={persona.avatar}
                    alt={persona.name}
                    className="w-11 h-11 rounded-2xl object-cover border border-sky-300 shadow-xs"
                  />
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {persona.name}
                    </p>
                    <p className="text-[11px] text-sky-600 dark:text-sky-400 font-semibold truncate">
                      {persona.title}
                    </p>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                      {persona.company}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Error notification */}
        {evaluationError && (
          <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{evaluationError}</span>
          </div>
        )}

        {/* Start Button */}
        <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-slate-100 dark:border-slate-800">
          <div className="text-xs text-slate-500 dark:text-slate-400 text-center sm:text-left">
            <span>Ready to generate <strong>{questionCount} tailored questions</strong> using Gemini AI</span>
          </div>

          <button
            onClick={handleStart}
            disabled={isGeneratingQuestions}
            className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-gradient-to-r from-sky-500 via-sky-600 to-lime-600 hover:from-sky-600 hover:to-lime-700 text-white font-extrabold text-sm shadow-lg shadow-sky-500/25 flex items-center justify-center gap-2.5 transition-all transform hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-60 cursor-pointer"
          >
            {isGeneratingQuestions ? (
              <>
                <RefreshCw className="w-5 h-5 animate-spin" />
                <span>Reading Resume & Architecting Questions...</span>
              </>
            ) : (
              <>
                <Play className="w-5 h-5 fill-current" />
                <span>Start Mock Interview Session</span>
              </>
            )}
          </button>
        </div>

      </div>
    </div>
  );
};
