import React from 'react';
import { Mic, X, CheckCircle, Volume2, Shield, Moon, Clock, ArrowRight } from 'lucide-react';

interface VoiceCommandsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VoiceCommandsModal: React.FC<VoiceCommandsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const commands = [
    {
      phrase: '"Submit answer" / "Finish answer"',
      action: 'Submits your current spoken or typed response for instant AI grading and feedback.',
      icon: CheckCircle,
      color: 'text-emerald-500'
    },
    {
      phrase: '"Repeat question" / "Read question again"',
      action: 'Has the AI interviewer persona re-read the active interview question out loud.',
      icon: Volume2,
      color: 'text-blue-500'
    },
    {
      phrase: '"Give hint" / "Show hint"',
      action: 'Opens the contextual hint to help structure your thoughts using the STAR method.',
      icon: Shield,
      color: 'text-amber-500'
    },
    {
      phrase: '"Next question" / "Move next"',
      action: 'Advances to the next question in your interview queue.',
      icon: ArrowRight,
      color: 'text-indigo-500'
    },
    {
      phrase: '"Pause timer" / "Resume timer"',
      action: 'Freezes or unfreezes the per-question countdown clock for thinking time.',
      icon: Clock,
      color: 'text-rose-500'
    },
    {
      phrase: '"Toggle dark mode" / "Dark mode"',
      action: 'Switches the interface between sleek dark mode and high-contrast light mode.',
      icon: Moon,
      color: 'text-purple-500'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 rounded-xl">
              <Mic className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-900 dark:text-white">Hands-Free Voice Commands</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Speak naturally during your interview session</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Command List */}
        <div className="p-5 space-y-3 max-h-[65vh] overflow-y-auto">
          {commands.map((cmd, idx) => {
            const Icon = cmd.icon;
            return (
              <div
                key={idx}
                className="flex items-start gap-3.5 p-3.5 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 hover:bg-slate-100/60 dark:hover:bg-slate-800/70 transition-colors"
              >
                <div className={`mt-0.5 p-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs ${cmd.color}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <span className="inline-block px-2.5 py-0.5 mb-1 text-xs font-semibold font-mono tracking-wide rounded-md bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800/60">
                    {cmd.phrase}
                  </span>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {cmd.action}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer info */}
        <div className="p-4 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
            <span>Microphone continuous listening is available in the Live Room</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-900 text-white dark:bg-white dark:text-slate-900 font-medium hover:opacity-90 transition-opacity"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
};
