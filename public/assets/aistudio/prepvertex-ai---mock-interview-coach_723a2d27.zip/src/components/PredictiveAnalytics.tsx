import React from 'react';
import {
  TrendingUp,
  Target,
  Sparkles,
  Zap,
  CheckCircle2,
  AlertCircle,
  BarChart3,
  Users2,
  Award,
  ArrowUpRight,
  ShieldCheck,
  Compass
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const PredictiveAnalytics: React.FC = () => {
  const { predictiveAnalytics, currentUser, setCurrentTab, userSessions } = useApp();
  const { hiringProbability, avgScore, totalSessions, skillPrioritization, cohortBenchmark, targetRole } = predictiveAnalytics;

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-12 animate-fade-in">
      
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 text-xs font-semibold border border-indigo-200/80 dark:border-indigo-800">
          <Sparkles className="w-3.5 h-3.5" />
          Predictive Hiring Probability & AI Task Prioritization
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
          Career Readiness & Workflow Optimization
        </h2>
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
          Machine-learning predictive analytics modeling your likelihood of clearing Tier-1 technical rounds based on score trends and automated prep roadmaps.
        </p>
      </div>

      {/* Main Probability & Cohort Cards */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        
        {/* Probability Gauge Card */}
        <div className="md:col-span-7 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Predictive Interview Pass Probability
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300">
                AI Modeled
              </span>
            </div>

            <div className="flex items-baseline gap-4 mb-3">
              <div className="text-5xl sm:text-6xl font-black bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                {hiringProbability}%
              </div>
              <div>
                <span className="text-xs font-bold text-slate-900 dark:text-white block">
                  {cohortBenchmark.readinessLevel}
                </span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400">
                  Target: {targetRole}
                </span>
              </div>
            </div>

            {/* Probability Progress Bar */}
            <div className="w-full bg-slate-100 dark:bg-slate-800 h-3 rounded-full overflow-hidden mb-4">
              <div
                style={{ width: `${hiringProbability}%` }}
                className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-500 rounded-full transition-all duration-1000"
              ></div>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              Based on your {totalSessions} completed mock interview sessions and an average score of <strong>{avgScore}/10</strong>, your technical articulation matches candidates who clear on-site rounds at leading tech employers.
            </p>
          </div>

          <div className="pt-6 mt-6 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
            <span className="text-slate-500 dark:text-slate-400">
              Confidence Factor: High (Multi-round evaluation)
            </span>
            <button
              onClick={() => setCurrentTab('setup')}
              className="font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
            >
              Boost Score with Practice →
            </button>
          </div>
        </div>

        {/* Cohort & Team Benchmarking Card */}
        <div className="md:col-span-5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Users2 className="w-4 h-4 text-purple-500" />
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                Team & Cohort Benchmark
              </h4>
            </div>

            <div className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/40">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-slate-600 dark:text-slate-400">Candidate Percentile Ranking</span>
                  <span className="font-extrabold text-indigo-600 dark:text-indigo-400">
                    Top {100 - cohortBenchmark.userPercentile}%
                  </span>
                </div>
                <div className="text-xl font-black text-slate-900 dark:text-white">
                  {cohortBenchmark.userPercentile}th Percentile
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
                  <span className="text-[10px] text-slate-400 block mb-0.5">Cohort Average</span>
                  <span className="text-sm font-extrabold text-slate-900 dark:text-white">
                    {cohortBenchmark.cohortAverageScore} / 10
                  </span>
                </div>
                <div className="p-3 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
                  <span className="text-[10px] text-slate-400 block mb-0.5">Top 10% Bar</span>
                  <span className="text-sm font-extrabold text-slate-900 dark:text-white">
                    {cohortBenchmark.topTenPercentScore} / 10
                  </span>
                </div>
              </div>

              <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                You are currently performing <strong>+{(avgScore - cohortBenchmark.cohortAverageScore).toFixed(1)} points</strong> above the peer candidate median in technical problem solving.
              </p>
            </div>
          </div>

          <div className="pt-4 mt-4 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span>Enterprise cohort data encrypted via AES-256</span>
          </div>
        </div>

      </div>

      {/* Automated Task Prioritization Roadmap */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm space-y-6">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-500" />
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Automated Task & Skill Gap Prioritization
              </h3>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Ranked prep recommendations calculated by prospective score gain and hiring impact
            </p>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300">
            4 Optimization Tasks
          </span>
        </div>

        <div className="space-y-3.5">
          {skillPrioritization.map((task, idx) => {
            const urgencyBadge = task.urgency === 'CRITICAL'
              ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300 border-rose-200'
              : task.urgency === 'HIGH'
              ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300 border-amber-200'
              : 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 border-indigo-200';

            return (
              <div
                key={idx}
                className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 hover:border-indigo-400 dark:hover:border-indigo-600 transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
              >
                <div className="flex items-start gap-3.5">
                  <div className="flex items-center justify-center w-8 h-8 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white font-bold text-xs shrink-0 shadow-xs">
                    #{idx + 1}
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                        {task.skill}
                      </h4>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${urgencyBadge}`}>
                        {task.urgency}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                      {task.actionItem}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 w-full md:w-auto justify-end shrink-0">
                  <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-900">
                    Expected Gain: {task.impactScore}
                  </span>
                  <button
                    onClick={() => setCurrentTab('setup')}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-xs"
                  >
                    <span>Practice Gap</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

      </div>

    </div>
  );
};
