import React, { useState } from 'react';
import {
  Users,
  MessageSquare,
  Sparkles,
  Send,
  CheckCircle2,
  ThumbsUp,
  AlertTriangle,
  Lightbulb,
  Edit3,
  Share2,
  Copy,
  Check
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const CollaborativeStudio: React.FC = () => {
  const { peerComments, addPeerComment, currentUser, setCurrentAnswerDraft, setCurrentTab } = useApp();
  const [collabDraft, setCollabDraft] = useState(`In my previous role leading the payments service, our checkout API experienced 500ms p99 latency spikes during holiday campaigns.
To resolve this, I profiled our database query plans and identified N+1 queries on merchant inventory checks.
I redesigned the data retrieval layer by introducing Redis caching with a write-through strategy and implemented distributed idempotency keys.
As a result, p99 latency dropped by 64% (from 510ms down to 180ms) and checkout conversion increased by 3.4% without any payment discrepancies.`);

  const [commentText, setCommentText] = useState('');
  const [commentType, setCommentType] = useState<'suggestion' | 'praise' | 'critique'>('suggestion');
  const [copiedLink, setCopiedLink] = useState(false);

  const handlePostComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    addPeerComment(commentText.trim(), commentType);
    setCommentText('');
  };

  const handlePushToInterview = () => {
    setCurrentAnswerDraft(collabDraft);
    setCurrentTab('room');
  };

  const handleCopyInvite = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-12 animate-fade-in">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-black text-slate-900 dark:text-white">
              Real-Time Collaborative Peer & Mentor Studio
            </h2>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300">
              Live Co-Pilot
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Pair with peers or mentors to refine STAR responses, annotate architecture diagrams, and practice collaborative rubric grading.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyInvite}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
          >
            {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5 text-indigo-500" />}
            <span>{copiedLink ? 'Invite Copied!' : 'Copy Peer Invite Link'}</span>
          </button>
        </div>
      </div>

      {/* Main Studio Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Collaborative Shared Answer Workspace */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-4">
          
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <Edit3 className="w-4 h-4 text-indigo-500" />
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                Collaborative Answer Drafting Canvas
              </h3>
            </div>
            
            {/* Active peer badges */}
            <div className="flex items-center gap-1.5">
              <span className="flex items-center gap-1.5 text-[11px] text-emerald-600 dark:text-emerald-400 font-medium bg-emerald-50 dark:bg-emerald-950/40 px-2.5 py-1 rounded-full border border-emerald-200 dark:border-emerald-800">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                David Vance (Staff Mentor) Active
              </span>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 flex items-center justify-between">
              <span>Shared Response Text (STAR Structured):</span>
              <span className="text-[11px]">{collabDraft.split(/\s+/).length} words</span>
            </label>
            <textarea
              value={collabDraft}
              onChange={(e) => setCollabDraft(e.target.value)}
              rows={12}
              className="w-full p-4 rounded-2xl border border-slate-300 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/40 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 leading-relaxed font-normal resize-none"
            />
          </div>

          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="text-xs text-slate-500 dark:text-slate-400">
              Changes sync real-time with your active peer reviewer
            </div>

            <button
              onClick={handlePushToInterview}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-500/20 flex items-center justify-center gap-2 transition-all"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Push Answer to Live Interview Room</span>
            </button>
          </div>

        </div>

        {/* Right: Real-time Mentor Comments & Rubric Annotations */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-5 flex flex-col justify-between">
          
          <div>
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-purple-500" />
                <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                  Live Peer Review Notes ({peerComments.length})
                </h4>
              </div>
              <span className="text-[10px] text-slate-400">Real-time sync</span>
            </div>

            {/* Comments Stream */}
            <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1">
              {peerComments.map((comment) => {
                const badge = comment.type === 'praise'
                  ? 'border-emerald-200 bg-emerald-50/50 dark:bg-emerald-950/20 text-emerald-700 dark:text-emerald-300'
                  : comment.type === 'critique'
                  ? 'border-rose-200 bg-rose-50/50 dark:bg-rose-950/20 text-rose-700 dark:text-rose-300'
                  : 'border-indigo-200 bg-indigo-50/50 dark:bg-indigo-950/20 text-indigo-700 dark:text-indigo-300';

                return (
                  <div
                    key={comment.id}
                    className={`p-3.5 rounded-2xl border ${badge} space-y-1.5`}
                  >
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <img
                          src={comment.avatar}
                          alt={comment.author}
                          className="w-5 h-5 rounded-full object-cover"
                        />
                        <span className="font-bold text-slate-900 dark:text-white">
                          {comment.author}
                        </span>
                      </div>
                      <span className="text-[10px] opacity-75">{comment.timestamp}</span>
                    </div>
                    <p className="text-xs text-slate-800 dark:text-slate-200 leading-relaxed">
                      {comment.text}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Comment submission form */}
          <form onSubmit={handlePostComment} className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
            <div className="flex gap-2">
              {[
                { type: 'suggestion', label: '💡 Suggestion' },
                { type: 'praise', label: '👍 Praise' },
                { type: 'critique', label: '⚠ Critique' }
              ].map((btn) => (
                <button
                  key={btn.type}
                  type="button"
                  onClick={() => setCommentType(btn.type as any)}
                  className={`text-[11px] px-2.5 py-1 rounded-lg border transition-all ${
                    commentType === btn.type
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 font-bold'
                      : 'border-slate-200 dark:border-slate-700 text-slate-500'
                  }`}
                >
                  {btn.label}
                </button>
              ))}
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder="Add peer critique or rubric notes..."
                className="flex-1 px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
              <button
                type="submit"
                disabled={!commentText.trim()}
                className="p-2.5 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-50 transition-colors"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </form>

        </div>

      </div>

    </div>
  );
};
