import React, { useState, useRef } from 'react';
import {
  UploadCloud,
  FileText,
  CheckCircle2,
  Sparkles,
  Edit3,
  Layers,
  Award,
  Code2,
  RefreshCw,
  FolderOpen
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { SAMPLE_RESUMES, extractTextFromFile } from '../utils/resumeParser';

export const ResumeUpload: React.FC = () => {
  const { currentResume, setResumeText, loadSampleResume } = useApp();
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showRawEditor, setShowRawEditor] = useState(false);
  const [rawTextDraft, setRawTextDraft] = useState(currentResume.rawText);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (file: File) => {
    setIsProcessing(true);
    try {
      const extracted = await extractTextFromFile(file);
      setResumeText(extracted);
      setRawTextDraft(extracted);
    } catch (err) {
      console.error('File extraction error:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  const handleApplyDraft = () => {
    setResumeText(rawTextDraft);
    setShowRawEditor(false);
  };

  return (
    <div className="space-y-6">
      {/* 1-Click Sample Resumes Bar */}
      <div className="p-4 rounded-3xl bg-sky-50/70 dark:bg-sky-950/30 border border-sky-100 dark:border-sky-900/60">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-sky-600 dark:text-sky-400" />
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-800 dark:text-slate-200">
              Quick Test: Select Industry Sample Resume
            </h4>
          </div>
          <span className="text-[11px] text-slate-500 dark:text-slate-400">
            Instant 1-click load for live interview testing
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {SAMPLE_RESUMES.map((sample) => (
            <button
              key={sample.id}
              onClick={() => {
                loadSampleResume(sample.id);
                setRawTextDraft(sample.text);
              }}
              className="group p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-sky-500 dark:hover:border-sky-400 hover:shadow-sm transition-all text-left flex flex-col justify-between"
            >
              <div>
                <span className="inline-block px-2 py-0.5 mb-1.5 text-[10px] font-bold rounded-md bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300">
                  {sample.highlightBadge}
                </span>
                <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                  {sample.name}
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                  {sample.title}
                </p>
              </div>
              <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[10px] text-sky-600 dark:text-sky-400 font-bold">
                <span>Load Profile</span>
                <span className="group-hover:translate-x-1 transition-transform">→</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Main Upload Dropzone */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Dropzone & File Input */}
        <div className="lg:col-span-5 flex flex-col justify-between">
          <div
            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-3xl p-6 text-center cursor-pointer transition-all flex flex-col items-center justify-center min-h-[220px] ${
              isDragging
                ? 'border-sky-500 bg-sky-50 dark:bg-sky-950/40'
                : 'border-slate-200 dark:border-slate-700 hover:border-sky-400 dark:hover:border-sky-500 bg-slate-50/50 dark:bg-slate-900/40'
            }`}
          >
            <input
              type="file"
              ref={fileInputRef}
              accept=".pdf,.docx,.txt,.md"
              className="hidden"
              onChange={(e) => {
                if (e.target.files && e.target.files[0]) {
                  handleFileUpload(e.target.files[0]);
                }
              }}
            />

            <div className="p-3.5 rounded-2xl bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 mb-3 shadow-xs">
              {isProcessing ? (
                <RefreshCw className="w-6 h-6 animate-spin" />
              ) : (
                <UploadCloud className="w-6 h-6" />
              )}
            </div>

            <p className="text-sm font-bold text-slate-900 dark:text-white mb-1">
              {isProcessing ? 'Analyzing Resume Architecture...' : 'Upload your Resume (PDF or DOCX)'}
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs mb-3">
              Drag and drop your file here, or click to browse files from your computer.
            </p>

            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-200/60 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[10px] font-semibold">
              <FolderOpen className="w-3 h-3" />
              PDF, DOCX, TXT supported
            </span>
          </div>

          <div className="mt-3 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 px-1">
            <span>Client-side extraction with AES-256 E2E encryption</span>
            <button
              onClick={() => setShowRawEditor(!showRawEditor)}
              className="text-sky-600 dark:text-sky-400 font-semibold hover:underline flex items-center gap-1"
            >
              <Edit3 className="w-3 h-3" />
              {showRawEditor ? 'Close Editor' : 'Edit Resume Text'}
            </button>
          </div>
        </div>

        {/* Right: Extracted Intelligence Preview */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-3xl border border-sky-100 dark:border-slate-800 p-5 shadow-xs">
          
          <div className="flex items-center justify-between pb-3.5 mb-3.5 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-2xl bg-lime-50 text-lime-700 dark:bg-lime-950/40 dark:text-lime-400 border border-lime-200">
                <CheckCircle2 className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-extrabold text-slate-900 dark:text-white">
                  Extracted Resume Intelligence
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Detected for {currentResume.name} • ~{currentResume.wordCount} words
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-bold px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                Exp: ~{currentResume.experienceYears} {currentResume.experienceYears === 1 ? 'Year' : 'Years'}
              </span>
            </div>
          </div>

          {!showRawEditor ? (
            <div className="space-y-4">
              {/* Detected Skills */}
              <div>
                <label className="text-xs font-bold text-slate-500 dark:text-slate-400 flex items-center gap-1.5 mb-2">
                  <Code2 className="w-3.5 h-3.5 text-sky-500" />
                  Detected Core Technical Competencies ({currentResume.skills.length})
                </label>
                <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto pr-1">
                  {currentResume.skills.map((skill, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 text-xs font-semibold rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200/80 dark:border-slate-700"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              {/* Projects & Highlights */}
              <div>
                <label className="text-xs font-bold text-slate-500 dark:text-slate-400 flex items-center gap-1.5 mb-2">
                  <Layers className="w-3.5 h-3.5 text-lime-600" />
                  Key Projects & Architectural Highlights
                </label>
                <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                  {currentResume.projects.map((proj, idx) => (
                    <div
                      key={idx}
                      className="text-xs p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-300"
                    >
                      {proj}
                    </div>
                  ))}
                </div>
              </div>

              {/* Target Role Guidance */}
              <div className="p-3 rounded-2xl bg-lime-50/70 dark:bg-lime-950/20 border border-lime-200/80 dark:border-lime-900/40 flex items-center justify-between text-xs text-lime-900 dark:text-lime-300">
                <span className="flex items-center gap-1.5">
                  <Award className="w-4 h-4 text-lime-600 dark:text-lime-400" />
                  AI will generate tailored questions matching: <strong>{currentResume.roleTarget}</strong>
                </span>
                <span className="text-[10px] font-bold uppercase tracking-wider">Ready</span>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block">
                Edit Raw Resume Content Directly:
              </label>
              <textarea
                value={rawTextDraft}
                onChange={(e) => setRawTextDraft(e.target.value)}
                rows={9}
                className="w-full p-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-slate-100 font-mono focus:outline-hidden focus:ring-2 focus:ring-sky-500"
                placeholder="Paste or type resume text here..."
              />
              <div className="flex justify-end gap-2">
                <button
                  onClick={() => setShowRawEditor(false)}
                  className="px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400"
                >
                  Cancel
                </button>
                <button
                  onClick={handleApplyDraft}
                  className="px-4 py-1.5 text-xs font-bold rounded-xl bg-sky-500 text-white hover:bg-sky-600"
                >
                  Apply Changes
                </button>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
