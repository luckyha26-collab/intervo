import React from 'react';
import {
  Play,
  TrendingUp,
  Award,
  Clock,
  Sparkles,
  ShieldCheck,
  Users,
  Layers,
  ArrowRight,
  Code2,
  CheckCircle2,
  Mic,
  Calendar,
  Brain,
  Radio,
  UserPlus
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Dashboard: React.FC = () => {
  const {
    currentUser,
    currentResume,
    userSessions,
    setCurrentTab,
    predictiveAnalytics,
    weaknessTopics
  } = useApp();

  const { hiringProbability, avgScore } = predictiveAnalytics;
  const criticalWeaknesses = weaknessTopics.filter(w => w.severity === 'Critical');

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-12 animate-fade-in">
      
      {/* Hero Welcome Banner in White, Glacier Light Blue & Olive */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-sky-500 via-sky-600 to-teal-700 p-8 sm:p-10 text-white shadow-xl">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-96 h-96 bg-lime-400/25 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-1/3 -mb-10 w-72 h-72 bg-white/20 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 max-w-2xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 border border-white/30 text-white text-xs font-bold backdrop-blur-xs">
            <Sparkles className="w-3.5 h-3.5 text-lime-300" />
            <span>AI Mock Interview Bar Raiser • Active: {currentUser.name}</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-black text-white leading-tight">
            Master Technical Rounds & Group Discussions with Instant AI Feedback
          </h1>

          <p className="text-xs sm:text-sm text-sky-100 leading-relaxed">
            Practice 1-on-1 resume-tailored interviews, join multi-candidate Group Discussion (GD) calls with peer invites, and eliminate weak technical topics using our intelligent Weakness Detector.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => setCurrentTab('setup')}
              className="px-6 py-3 rounded-2xl bg-white text-sky-800 hover:bg-sky-50 font-extrabold text-xs sm:text-sm shadow-lg shadow-sky-900/20 flex items-center gap-2 transition-all transform hover:-translate-y-0.5"
            >
              <Play className="w-4 h-4 fill-current text-sky-600" />
              <span>Start New Mock Interview</span>
            </button>

            <button
              onClick={() => setCurrentTab('gd-room')}
              className="px-5 py-3 rounded-2xl bg-lime-500 hover:bg-lime-400 text-slate-900 font-extrabold text-xs sm:text-sm shadow-md transition-all flex items-center gap-2"
            >
              <Radio className="w-4 h-4 text-slate-900" />
              <span>Join Live GD Arena</span>
            </button>

            <button
              onClick={() => setCurrentTab('weaknesses')}
              className="px-4 py-3 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/30 text-white font-bold text-xs sm:text-sm transition-all flex items-center gap-2"
            >
              <Brain className="w-4 h-4 text-lime-300" />
              <span>Weakness Detector ({weaknessTopics.length})</span>
            </button>
          </div>
        </div>
      </div>

      {/* Feature Spotlights: Weakness Detector & GD Arena Quick Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* Spotlight 1: Weakness Detector */}
        <div
          onClick={() => setCurrentTab('weaknesses')}
          className="p-6 rounded-3xl border border-sky-100 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-sky-400 dark:hover:border-sky-600 shadow-xs cursor-pointer transition-all space-y-3 group"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2.5 rounded-2xl bg-lime-50 text-lime-700 dark:bg-lime-950/40 dark:text-lime-400 border border-lime-200">
                <Brain className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">
                  Feature 14: AI Weakness Detector
                </h3>
                <p className="text-[11px] text-slate-500">
                  Topic gap diagnosis & targeted remediation
                </p>
              </div>
            </div>
            <span className="text-xs font-bold text-lime-700 dark:text-lime-400 group-hover:translate-x-1 transition-transform">
              Explore →
            </span>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            Identifies vulnerabilities in cache invalidation, STAR metric quantification, and database indexing. Launch 1-click targeted drills.
          </p>
          <div className="flex items-center gap-2 text-[11px] font-semibold text-rose-600 dark:text-rose-400">
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
            <span>{criticalWeaknesses.length} Critical topics need improvement</span>
          </div>
        </div>

        {/* Spotlight 2: Group Discussion (GD) Arena */}
        <div
          onClick={() => setCurrentTab('gd-room')}
          className="p-6 rounded-3xl border border-sky-100 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-sky-400 dark:hover:border-sky-600 shadow-xs cursor-pointer transition-all space-y-3 group"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2.5 rounded-2xl bg-sky-50 text-sky-600 dark:bg-sky-950/40 dark:text-sky-400 border border-sky-200">
                <Radio className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">
                  Group Discussion (GD) Call Arena
                </h3>
                <p className="text-[11px] text-slate-500">
                  Multi-candidate video call & AI Bar Raiser
                </p>
              </div>
            </div>
            <span className="text-xs font-bold text-sky-600 dark:text-sky-400 group-hover:translate-x-1 transition-transform">
              Enter Call →
            </span>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            Invite friends to a live technical round table with speaking indicators, raise hand alerts, and instant post-GD leadership scorecards.
          </p>
          <div className="flex items-center gap-2 text-[11px] font-semibold text-lime-700 dark:text-lime-400">
            <span className="w-2 h-2 rounded-full bg-lime-500"></span>
            <span>5 Active Speakers currently in room</span>
          </div>
        </div>

      </div>

      {/* High-Level Overview Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Metric 1 */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-sky-100 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-medium mb-2">
            <span>Interview Pass Probability</span>
            <Sparkles className="w-4 h-4 text-sky-500" />
          </div>
          <div className="text-3xl font-black text-slate-900 dark:text-white">
            {hiringProbability}%
          </div>
          <div className="mt-2 flex items-center gap-1.5 text-[11px] text-lime-700 dark:text-lime-400 font-bold">
            <span>Tier-1 Tech Readiness</span>
            <span className="text-slate-400">• Modeled</span>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-sky-100 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-medium mb-2">
            <span>Average Score</span>
            <Award className="w-4 h-4 text-lime-600" />
          </div>
          <div className="text-3xl font-black text-slate-900 dark:text-white">
            {avgScore} <span className="text-xs font-normal text-slate-400">/ 10</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-400">
            Across {userSessions.length} completed sessions
          </div>
        </div>

        {/* Metric 3 */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-sky-100 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-medium mb-2">
            <span>Target Role Focus</span>
            <Layers className="w-4 h-4 text-sky-500" />
          </div>
          <div className="text-xl font-bold text-slate-900 dark:text-white truncate">
            {currentUser.targetRole}
          </div>
          <div className="mt-2 text-[11px] text-sky-600 dark:text-sky-400 font-medium">
            Resume grounded & extracted
          </div>
        </div>

        {/* Metric 4 */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-sky-100 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-medium mb-2">
            <span>Data Vault Security</span>
            <ShieldCheck className="w-4 h-4 text-lime-600" />
          </div>
          <div className="text-xl font-bold text-lime-700 dark:text-lime-400">
            AES-256 E2E
          </div>
          <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-400">
            Zero-knowledge isolation
          </div>
        </div>

      </div>

      {/* Split Section: Current Resume Context & Recent Practice Records */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Active Resume Intelligence Card */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-3xl border border-sky-100 dark:border-slate-800 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <Code2 className="w-4 h-4 text-sky-500" />
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                Active Resume Profile
              </h3>
            </div>
            <button
              onClick={() => setCurrentTab('setup')}
              className="text-xs text-sky-600 dark:text-sky-400 font-semibold hover:underline"
            >
              Change / Upload
            </button>
          </div>

          <div className="space-y-3">
            <div>
              <p className="text-sm font-bold text-slate-900 dark:text-white">
                {currentResume.name}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {currentResume.email} • ~{currentResume.experienceYears} Years Exp
              </p>
            </div>

            <div>
              <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5">
                Target Competencies Extracted ({currentResume.skills.length})
              </label>
              <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto pr-1">
                {currentResume.skills.slice(0, 10).map((skill, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 text-xs rounded-md bg-sky-50 dark:bg-slate-800 text-sky-800 dark:text-sky-200 border border-sky-100 dark:border-slate-700"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300">
              <span className="font-bold block mb-0.5 text-slate-800 dark:text-white">Top Project Highlight:</span>
              <p className="line-clamp-2">
                {currentResume.projects[0] || 'Full stack architectural deployment'}
              </p>
            </div>
          </div>
        </div>

        {/* Right: Recent Interview Sessions */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-3xl border border-sky-100 dark:border-slate-800 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              Recent Mock Interview Sessions
            </h3>
            <button
              onClick={() => setCurrentTab('history')}
              className="text-xs text-sky-600 dark:text-sky-400 font-semibold hover:underline flex items-center gap-1"
            >
              <span>View All ({userSessions.length})</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {userSessions.length === 0 ? (
            <div className="text-center py-8 space-y-3">
              <p className="text-xs text-slate-500 dark:text-slate-400">
                No past sessions recorded for {currentUser.name} yet.
              </p>
              <button
                onClick={() => setCurrentTab('setup')}
                className="px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs shadow-xs"
              >
                Launch Your First Mock Interview
              </button>
            </div>
          ) : (
            <div className="space-y-2.5">
              {userSessions.slice(0, 3).map((sess) => (
                <div
                  key={sess.id}
                  onClick={() => setCurrentTab('history')}
                  className="p-3.5 rounded-2xl border border-sky-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 hover:border-sky-300 dark:hover:border-sky-500 transition-all flex items-center justify-between cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex items-center justify-center w-9 h-9 rounded-xl bg-sky-500 text-white font-bold text-xs">
                      {sess.overallScore}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                        {sess.targetRole} {sess.wasStoppedEarly && <span className="text-[10px] text-amber-600 font-normal">(Partial)</span>}
                      </h4>
                      <p className="text-[11px] text-slate-400">
                        {sess.difficulty} • {sess.questions.length} questions • {new Date(sess.completedAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <span className="text-xs font-medium text-sky-600 dark:text-sky-400">
                    Review →
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
