import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Clock,
  Send,
  HelpCircle,
  Sparkles,
  Users,
  CheckCircle,
  RefreshCw,
  AlertCircle,
  Pause,
  Play,
  RotateCcw,
  StopCircle,
  AlertTriangle,
  FileCheck,
  X,
  ArrowRight
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { INTERVIEWER_PERSONAS, speakText, isSpeechRecognitionSupported, parseVoiceCommand } from '../utils/speechEngine';
import { AnswerFeedbackModal } from './AnswerFeedbackModal';

export const LiveInterviewRoom: React.FC = () => {
  const {
    activeSession,
    currentQuestionIndex,
    currentAnswerDraft,
    setCurrentAnswerDraft,
    isEvaluating,
    submitAndEvaluateCurrentAnswer,
    timerSecondsLeft,
    isTimerPaused,
    setIsTimerPaused,
    activePersonaId,
    stopInterviewAndFinishPartial,
    discardActiveSession,
    peerComments,
    addPeerComment,
    setLastVoiceCommand,
    toggleDarkMode
  } = useApp();

  // Voice recording state
  const [isListening, setIsListening] = useState(false);
  const [isSpeakingQuestion, setIsSpeakingQuestion] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [showPeerDrawer, setShowPeerDrawer] = useState(false);
  const [showStopModal, setShowStopModal] = useState(false);
  const [newPeerNote, setNewPeerNote] = useState('');
  const [micAudioLevel, setMicAudioLevel] = useState(0);

  const recognitionRef = useRef<any>(null);
  const cancelSpeechRef = useRef<(() => void) | null>(null);

  if (!activeSession) return null;

  const currentItem = activeSession.questions[currentQuestionIndex];
  const question = currentItem.question;
  const persona = INTERVIEWER_PERSONAS.find(p => p.id === activePersonaId) || INTERVIEWER_PERSONAS[0];

  // Auto-speak question on index change
  useEffect(() => {
    setShowHint(false);
    if (cancelSpeechRef.current) {
      cancelSpeechRef.current();
    }

    setIsSpeakingQuestion(true);
    const cancel = speakText(question.question, persona.id, () => {
      setIsSpeakingQuestion(false);
    });
    cancelSpeechRef.current = cancel;

    return () => {
      if (cancelSpeechRef.current) cancelSpeechRef.current();
    };
  }, [currentQuestionIndex, question.question, persona.id]);

  // Speech Recognition & Voice Commands listener
  useEffect(() => {
    if (!isSpeechRecognitionSupported()) return;

    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRec();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onresult = (event: any) => {
      let finalTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        }
      }

      if (finalTranscript) {
        // Check for Hands-free Voice Commands
        const cmd = parseVoiceCommand(finalTranscript);
        if (cmd) {
          setLastVoiceCommand(cmd.rawPhrase);
          setTimeout(() => setLastVoiceCommand(null), 3500);

          if (cmd.action === 'submit') {
            submitAndEvaluateCurrentAnswer();
            return;
          } else if (cmd.action === 'repeat') {
            handleRepeatQuestion();
            return;
          } else if (cmd.action === 'hint') {
            setShowHint(prev => !prev);
            return;
          } else if (cmd.action === 'timer') {
            setIsTimerPaused(prev => !prev);
            return;
          } else if (cmd.action === 'clear') {
            setCurrentAnswerDraft('');
            return;
          } else if (cmd.action === 'theme') {
            toggleDarkMode();
            return;
          }
        }

        // Otherwise append spoken text to draft
        setCurrentAnswerDraft(prev => (prev ? `${prev} ${finalTranscript.trim()}` : finalTranscript.trim()));
      }
    };

    recognition.onerror = (e: any) => {
      console.warn('Speech recognition status:', e);
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current = recognition;

    return () => {
      try {
        recognition.stop();
      } catch {}
    };
  }, [question, persona.id]);

  const toggleMic = () => {
    if (!recognitionRef.current) return;
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
      setMicAudioLevel(0);
    } else {
      try {
        recognitionRef.current.start();
        setIsListening(true);
        // Simulate dynamic sound wave levels
        const interval = setInterval(() => {
          if (!isListening) {
            clearInterval(interval);
            return;
          }
          setMicAudioLevel(Math.floor(Math.random() * 80) + 20);
        }, 150);
      } catch (err) {
        console.warn('Microphone start error:', err);
      }
    }
  };

  const handleRepeatQuestion = () => {
    if (cancelSpeechRef.current) cancelSpeechRef.current();
    setIsSpeakingQuestion(true);
    const cancel = speakText(question.question, persona.id, () => {
      setIsSpeakingQuestion(false);
    });
    cancelSpeechRef.current = cancel;
  };

  const handleStopSpeech = () => {
    if (cancelSpeechRef.current) {
      cancelSpeechRef.current();
      setIsSpeakingQuestion(false);
    }
  };

  // Timer calculation
  const totalTimer = activeSession.timerPerQuestion;
  const isTimeCritical = totalTimer > 0 && timerSecondsLeft <= 20;

  // Add peer note
  const handleAddPeerNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPeerNote.trim()) return;
    addPeerComment(newPeerNote.trim(), 'suggestion');
    setNewPeerNote('');
  };

  const wordCount = currentAnswerDraft.trim() ? currentAnswerDraft.trim().split(/\s+/).length : 0;
  const answeredCount = activeSession.questions.filter(q => q.feedback).length;

  const insertTemplate = (prefix: string) => {
    setCurrentAnswerDraft(prev => (prev ? `${prev}\n${prefix}: ` : `${prefix}: `));
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12 animate-fade-in relative">
      
      {/* Top Session Progress Bar with White, Glacier Light Blue & Olive Accents */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-sky-100 dark:border-slate-800 p-4 sm:p-5 shadow-xs flex flex-wrap items-center justify-between gap-4">
        
        {/* Left: Question Counter & Category */}
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-10 h-10 rounded-2xl bg-sky-500 text-white font-extrabold text-sm shadow-md shadow-sky-500/20">
            Q{currentQuestionIndex + 1}/{activeSession.questions.length}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-extrabold text-slate-900 dark:text-white">
                {activeSession.targetRole}
              </span>
              <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${
                activeSession.difficulty === 'Hard' ? 'bg-rose-50 text-rose-700 border-rose-200' :
                activeSession.difficulty === 'Medium' ? 'bg-amber-50 text-amber-700 border-amber-200' :
                'bg-lime-50 text-lime-800 border-lime-200'
              }`}>
                {activeSession.difficulty}
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Focus: {activeSession.categoryFocus} • {answeredCount} answered so far
            </p>
          </div>
        </div>

        {/* Center: Countdown Timer */}
        {totalTimer > 0 && (
          <div className={`flex items-center gap-3 px-4 py-2 rounded-2xl border transition-all ${
            isTimeCritical
              ? 'bg-rose-500/10 border-rose-500/30 text-rose-600 dark:text-rose-400 animate-pulse'
              : 'bg-sky-50/70 dark:bg-slate-800/60 border-sky-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
          }`}>
            <Clock className={`w-4 h-4 ${isTimeCritical ? 'text-rose-500' : 'text-sky-500'}`} />
            <div className="font-mono text-sm font-bold">
              {Math.floor(timerSecondsLeft / 60)}:{(timerSecondsLeft % 60).toString().padStart(2, '0')}
            </div>
            <button
              onClick={() => setIsTimerPaused(!isTimerPaused)}
              className="p-1 rounded-md hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 transition-colors"
              title={isTimerPaused ? 'Resume countdown' : 'Pause countdown'}
            >
              {isTimerPaused ? <Play className="w-3.5 h-3.5 fill-current" /> : <Pause className="w-3.5 h-3.5" />}
            </button>
          </div>
        )}

        {/* Right: Stop Interview Early Feature & Peer Co-pilot */}
        <div className="flex items-center gap-2">
          
          <button
            onClick={() => setShowPeerDrawer(!showPeerDrawer)}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl border text-xs font-semibold transition-all ${
              showPeerDrawer
                ? 'bg-sky-500 text-white border-sky-500 shadow-xs'
                : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Peer Co-Pilot ({peerComments.length})</span>
          </button>

          {/* STOP INTERVIEW BUTTON */}
          <button
            onClick={() => setShowStopModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-rose-700 dark:text-rose-300 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-950/70 border border-rose-200 dark:border-rose-900 transition-all shadow-xs"
            title="Stop or pause the interview session"
          >
            <StopCircle className="w-4 h-4 text-rose-500" />
            <span>Stop Interview</span>
          </button>

        </div>

      </div>

      {/* Main Grid: Left Stage (Interviewer) & Right Workspace (Candidate) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Stage: Interviewer Stage */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* Persona Card in White & Light Blue */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-sky-100 dark:border-slate-800 p-6 shadow-sm space-y-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3.5">
                <div className="relative">
                  <img
                    src={persona.avatar}
                    alt={persona.name}
                    className="w-14 h-14 rounded-2xl object-cover border-2 border-sky-400 shadow-xs"
                  />
                  {isSpeakingQuestion && (
                    <span className="absolute -bottom-1 -right-1 flex h-4 w-4">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-4 w-4 bg-sky-500 border-2 border-white dark:border-slate-900"></span>
                    </span>
                  )}
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                    {persona.name}
                  </h3>
                  <p className="text-xs text-sky-600 dark:text-sky-400 font-semibold">
                    {persona.title}
                  </p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    {persona.company}
                  </p>
                </div>
              </div>

              {/* Audio Controls */}
              <button
                onClick={isSpeakingQuestion ? handleStopSpeech : handleRepeatQuestion}
                className={`p-2.5 rounded-2xl border transition-all ${
                  isSpeakingQuestion
                    ? 'border-sky-400 bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 shadow-xs animate-pulse'
                    : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
                title={isSpeakingQuestion ? 'Mute AI Voice' : 'Repeat Question Audio'}
              >
                {isSpeakingQuestion ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
              </button>
            </div>

            {/* Speaking animated waveform indicator */}
            {isSpeakingQuestion && (
              <div className="flex items-center justify-center gap-1.5 py-1 px-3.5 rounded-full bg-sky-50 dark:bg-sky-950/60 border border-sky-200 text-xs text-sky-700 dark:text-sky-300">
                <span className="w-1 h-3 bg-sky-500 rounded-full animate-bounce"></span>
                <span className="w-1 h-4 bg-sky-600 rounded-full animate-bounce [animation-delay:0.15s]"></span>
                <span className="w-1 h-5 bg-lime-500 rounded-full animate-bounce [animation-delay:0.3s]"></span>
                <span className="w-1 h-3 bg-sky-600 rounded-full animate-bounce [animation-delay:0.45s]"></span>
                <span className="ml-2 font-medium">Reading question out loud...</span>
              </div>
            )}

            {/* Grounded Resume Snippet */}
            {question.contextSnippet && (
              <div className="p-3 rounded-2xl bg-lime-50/70 dark:bg-lime-950/20 border border-lime-200/80 dark:border-lime-900/40 text-xs text-lime-900 dark:text-lime-300">
                <span className="font-bold block mb-0.5">Resume Context:</span>
                <span>{question.contextSnippet}</span>
              </div>
            )}

            {/* Question Text */}
            <div className="space-y-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                Interview Question #{currentQuestionIndex + 1}
              </span>
              <p className="text-sm sm:text-base font-bold text-slate-900 dark:text-white leading-relaxed">
                "{question.question}"
              </p>
            </div>

            {/* Expected Key Points Checklist */}
            {question.expectedKeyPoints && question.expectedKeyPoints.length > 0 && (
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                  <CheckCircle className="w-3.5 h-3.5 text-lime-600" />
                  Key Points the Interviewer is Evaluating
                </span>
                <ul className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
                  {question.expectedKeyPoints.map((pt, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-sky-500 font-bold">•</span>
                      <span>{pt}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Hint Accordion */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => setShowHint(!showHint)}
                className="flex items-center justify-between w-full text-xs font-semibold text-sky-600 dark:text-sky-400 hover:underline"
              >
                <span className="flex items-center gap-1.5">
                  <HelpCircle className="w-3.5 h-3.5" />
                  {showHint ? 'Hide Response Hint' : 'Need a hint? (Or say "Give hint")'}
                </span>
                <span>{showHint ? '▲' : '▼'}</span>
              </button>
              {showHint && (
                <div className="mt-2.5 p-3 rounded-2xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-900/50 text-xs text-amber-900 dark:text-amber-300 leading-relaxed animate-fade-in">
                  💡 {question.hint}
                </div>
              )}
            </div>

          </div>

        </div>

        {/* Right Stage: Candidate Workspace */}
        <div className="lg:col-span-7 space-y-4">
          
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-sky-100 dark:border-slate-800 p-6 shadow-sm space-y-4">
            
            {/* Top Bar: Hands-free Mic Toggle & Status */}
            <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
              
              <div className="flex items-center gap-2.5">
                <button
                  onClick={toggleMic}
                  className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-bold transition-all shadow-xs ${
                    isListening
                      ? 'bg-rose-500 text-white shadow-rose-500/25 animate-pulse'
                      : 'bg-gradient-to-r from-sky-500 to-sky-600 hover:from-sky-600 hover:to-sky-700 text-white shadow-sky-500/20'
                  }`}
                >
                  {isListening ? (
                    <>
                      <MicOff className="w-4 h-4" />
                      <span>Stop Listening</span>
                    </>
                  ) : (
                    <>
                      <Mic className="w-4 h-4" />
                      <span>Speak Answer (Voice-to-Text)</span>
                    </>
                  )}
                </button>

                {isListening && (
                  <div className="flex items-center gap-1 px-2.5 py-1 bg-lime-50 dark:bg-slate-800 rounded-xl border border-lime-200">
                    <span className="w-1.5 h-3 bg-lime-500 rounded-full animate-bounce"></span>
                    <span className="w-1.5 h-4 bg-lime-600 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                    <span className="w-1.5 h-2.5 bg-lime-500 rounded-full animate-bounce [animation-delay:0.4s]"></span>
                    <span className="text-[11px] font-mono text-lime-900 dark:text-lime-300 ml-1">Live STT Active</span>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                <span>{wordCount} words</span>
                <span>•</span>
                <button
                  onClick={() => setCurrentAnswerDraft('')}
                  className="hover:text-rose-500 transition-colors"
                  title="Clear draft"
                >
                  <RotateCcw className="w-3.5 h-3.5 inline mr-1" />
                  Clear
                </button>
              </div>

            </div>

            {/* Quick STAR Formatting Helpers */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              <span className="text-[11px] font-bold text-slate-400 mr-1">Insert Template:</span>
              <button
                type="button"
                onClick={() => insertTemplate('Situation')}
                className="px-2.5 py-1 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-800 text-[11px] font-semibold border border-sky-200"
              >
                + Situation
              </button>
              <button
                type="button"
                onClick={() => insertTemplate('Task')}
                className="px-2.5 py-1 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-800 text-[11px] font-semibold border border-sky-200"
              >
                + Task
              </button>
              <button
                type="button"
                onClick={() => insertTemplate('Technical Action')}
                className="px-2.5 py-1 rounded-lg bg-lime-50 hover:bg-lime-100 text-lime-800 text-[11px] font-semibold border border-lime-200"
              >
                + Action
              </button>
              <button
                type="button"
                onClick={() => insertTemplate('Quantified Result')}
                className="px-2.5 py-1 rounded-lg bg-lime-50 hover:bg-lime-100 text-lime-800 text-[11px] font-semibold border border-lime-200"
              >
                + Result
              </button>
            </div>

            {/* Answer Textarea */}
            <div className="relative">
              <textarea
                value={currentAnswerDraft}
                onChange={(e) => setCurrentAnswerDraft(e.target.value)}
                placeholder="Type your answer here or click 'Speak Answer' to speak using your microphone. You can also say 'Submit answer' when finished..."
                rows={11}
                className="w-full p-4 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/40 text-sm text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-sky-500 leading-relaxed resize-none font-normal"
              />
            </div>

            {/* Action Buttons */}
            <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-sky-500" />
                <span>Instant structured grading (Score, Strengths, Gaps, Model Answer)</span>
              </div>

              <button
                onClick={() => submitAndEvaluateCurrentAnswer()}
                disabled={isEvaluating || !currentAnswerDraft.trim()}
                className="w-full sm:w-auto px-7 py-3 rounded-2xl bg-gradient-to-r from-sky-500 via-sky-600 to-teal-600 hover:from-sky-600 hover:to-teal-700 text-white font-extrabold text-xs shadow-md shadow-sky-500/20 flex items-center justify-center gap-2 transition-all disabled:opacity-50 cursor-pointer"
              >
                {isEvaluating ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Bar Raiser is Scoring Your Answer...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Submit Answer for AI Grading</span>
                  </>
                )}
              </button>
            </div>

          </div>

        </div>

      </div>

      {/* STOP INTERVIEW CONFIRMATION MODAL */}
      {showStopModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white dark:bg-slate-900 border border-sky-100 dark:border-slate-800 rounded-3xl w-full max-w-lg shadow-2xl p-6 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-rose-50 text-rose-600 rounded-2xl border border-rose-200">
                  <StopCircle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                    Stop Interview Session?
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    You have completed {answeredCount} of {activeSession.questions.length} questions.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowStopModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              Choose how you want to conclude this session. You can generate a partial report from the questions you answered, or discard the session.
            </p>

            <div className="space-y-3">
              {answeredCount > 0 && (
                <button
                  onClick={() => {
                    setShowStopModal(false);
                    stopInterviewAndFinishPartial();
                  }}
                  className="w-full p-4 rounded-2xl border-2 border-sky-500 bg-sky-50/60 dark:bg-sky-950/40 hover:bg-sky-100 text-left transition-all flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <FileCheck className="w-5 h-5 text-sky-600" />
                    <div>
                      <div className="text-xs font-bold text-sky-900 dark:text-sky-200">
                        End Early & Generate Partial Report
                      </div>
                      <div className="text-[11px] text-sky-700/80 dark:text-sky-300/80">
                        Scores your {answeredCount} answered questions and saves to history.
                      </div>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-sky-600" />
                </button>
              )}

              <button
                onClick={() => {
                  setShowStopModal(false);
                  discardActiveSession();
                }}
                className="w-full p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 hover:bg-rose-50 hover:border-rose-300 text-left transition-all flex items-center gap-3 text-slate-700 dark:text-slate-300"
              >
                <AlertTriangle className="w-4 h-4 text-rose-500" />
                <div>
                  <div className="text-xs font-bold text-rose-700 dark:text-rose-400">
                    Discard Interview Session
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Exits to dashboard without saving this session.
                  </div>
                </div>
              </button>

              <button
                onClick={() => setShowStopModal(false)}
                className="w-full py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:underline text-center"
              >
                Resume Interview
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Peer Review Co-Pilot Drawer */}
      {showPeerDrawer && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-sky-100 dark:border-slate-800 p-6 shadow-xl animate-fade-in space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-2xl bg-sky-500/10 text-sky-600">
                <Users className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  Real-time Collaborative Peer & Mentor Review Studio
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Collaborative answer refinement and live annotations
                </p>
              </div>
            </div>
            <button
              onClick={() => setShowPeerDrawer(false)}
              className="text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              ✕ Close Co-Pilot
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
              {peerComments.map((comment) => (
                <div
                  key={comment.id}
                  className="p-3 rounded-2xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <img
                        src={comment.avatar}
                        alt={comment.author}
                        className="w-5 h-5 rounded-full object-cover"
                      />
                      <span className="text-xs font-bold text-slate-900 dark:text-white">
                        {comment.author}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-400">{comment.timestamp}</span>
                  </div>
                  <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                    {comment.text}
                  </p>
                </div>
              ))}
            </div>

            <form onSubmit={handleAddPeerNote} className="space-y-3">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block">
                Add Peer Reviewer Feedback or Rubric Critique:
              </label>
              <textarea
                value={newPeerNote}
                onChange={(e) => setNewPeerNote(e.target.value)}
                rows={3}
                placeholder="e.g. Suggest mentioning Redis cache invalidation strategies or STAR metrics..."
                className="w-full p-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
              />
              <div className="flex justify-end">
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-sky-500 text-white font-bold text-xs hover:bg-sky-600 shadow-xs"
                >
                  Post Peer Suggestion
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Answer Feedback Modal Overlay */}
      <AnswerFeedbackModal />

    </div>
  );
};
