import React, { useState } from 'react';
import {
  UserCheck,
  X,
  UserPlus,
  LogIn,
  ShieldCheck,
  Check,
  Eye,
  EyeOff,
  Sparkles,
  Lock,
  Mail,
  User as UserIcon,
  Briefcase
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    setIsAuthModalOpen,
    currentUser,
    usersList,
    login,
    signup,
    switchUser,
    logout,
    isLoggedIn
  } = useApp();

  const [mode, setMode] = useState<'login' | 'signup' | 'switch'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [targetRole, setTargetRole] = useState('Frontend Developer');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isAuthModalOpen) return null;

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    if (!email.trim()) {
      setErrorMsg('Please enter your email.');
      return;
    }
    const res = login(email, password);
    if (res.success) {
      setSuccessMsg(`Welcome back, ${currentUser.name}!`);
      setTimeout(() => {
        setSuccessMsg(null);
        setIsAuthModalOpen(false);
      }, 700);
    } else {
      setErrorMsg(res.message || 'Login failed.');
    }
  };

  const handleSignupSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    if (!name.trim() || !email.trim()) {
      setErrorMsg('Please fill in all required fields.');
      return;
    }
    const res = signup(name, email, password || 'password123', targetRole);
    if (res.success) {
      setSuccessMsg(`Profile created! Welcome, ${name.trim()}!`);
      setTimeout(() => {
        setSuccessMsg(null);
        setIsAuthModalOpen(false);
      }, 700);
    } else {
      setErrorMsg(res.message || 'Signup failed.');
    }
  };

  const handleQuickLogin = (demoEmail: string) => {
    setErrorMsg(null);
    login(demoEmail, 'password123');
    setSuccessMsg('Logged in successfully!');
    setTimeout(() => {
      setSuccessMsg(null);
      setIsAuthModalOpen(false);
    }, 500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white dark:bg-slate-900 border border-sky-100 dark:border-slate-800 rounded-3xl w-full max-w-md shadow-2xl overflow-hidden transition-all">
        
        {/* Header with White/Light Blue & Olive banner */}
        <div className="p-6 border-b border-sky-100 dark:border-slate-800 bg-gradient-to-r from-sky-50 via-white to-lime-50 dark:from-slate-900 dark:via-slate-800/80 dark:to-slate-900 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-sky-500/10 text-sky-600 dark:text-sky-400 rounded-2xl border border-sky-200/60 dark:border-sky-800">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-900 dark:text-white text-base">
                {mode === 'login' ? 'Candidate Login' : mode === 'signup' ? 'Create Candidate Account' : 'Switch Candidate Profile'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                User-isolated interview vaults & history
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsAuthModalOpen(false)}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Toggle */}
        <div className="grid grid-cols-3 p-1.5 m-5 mb-2 bg-slate-100 dark:bg-slate-800 rounded-2xl text-xs font-semibold">
          <button
            onClick={() => { setMode('login'); setErrorMsg(null); }}
            className={`py-2 rounded-xl transition-all ${
              mode === 'login'
                ? 'bg-white dark:bg-slate-900 text-sky-700 dark:text-sky-300 shadow-xs font-bold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Log In
          </button>
          <button
            onClick={() => { setMode('signup'); setErrorMsg(null); }}
            className={`py-2 rounded-xl transition-all ${
              mode === 'signup'
                ? 'bg-white dark:bg-slate-900 text-sky-700 dark:text-sky-300 shadow-xs font-bold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Sign Up
          </button>
          <button
            onClick={() => { setMode('switch'); setErrorMsg(null); }}
            className={`py-2 rounded-xl transition-all ${
              mode === 'switch'
                ? 'bg-white dark:bg-slate-900 text-sky-700 dark:text-sky-300 shadow-xs font-bold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Profiles
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 pt-2 space-y-4">
          
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs">
              {errorMsg}
            </div>
          )}

          {successMsg && (
            <div className="p-3 rounded-xl bg-lime-50 dark:bg-lime-950/40 border border-lime-200 dark:border-lime-900 text-lime-800 dark:text-lime-300 text-xs flex items-center gap-1.5">
              <Check className="w-4 h-4 text-lime-600" />
              <span>{successMsg}</span>
            </div>
          )}

          {mode === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-3.5">
              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 mb-1">
                  <Mail className="w-3.5 h-3.5 text-sky-500" />
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  placeholder="e.g. aarav.sharma@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 mb-1">
                  <Lock className="w-3.5 h-3.5 text-sky-500" />
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Enter password (e.g. password123)"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-sky-500 focus:outline-hidden pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-sky-500 to-sky-600 hover:from-sky-600 hover:to-sky-700 text-white font-bold text-xs shadow-md shadow-sky-500/20 transition-all flex items-center justify-center gap-2"
              >
                <LogIn className="w-4 h-4" />
                <span>Sign In to PrepVertex</span>
              </button>

              {/* 1-Click Instant Demo Login */}
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
                <span className="text-[11px] font-semibold text-slate-400 block mb-2 uppercase tracking-wider">
                  Quick 1-Click Demo Profiles:
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleQuickLogin('aarav.sharma@example.com')}
                    className="p-2 rounded-xl border border-sky-200 dark:border-slate-700 bg-sky-50/50 dark:bg-slate-800 hover:bg-sky-100 text-left text-xs text-sky-900 dark:text-sky-300"
                  >
                    <div className="font-bold truncate">Aarav (Fresher)</div>
                    <div className="text-[10px] text-slate-500 truncate">Frontend Dev</div>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickLogin('priya.patel@example.com')}
                    className="p-2 rounded-xl border border-lime-200 dark:border-slate-700 bg-lime-50/50 dark:bg-slate-800 hover:bg-lime-100 text-left text-xs text-lime-900 dark:text-lime-300"
                  >
                    <div className="font-bold truncate">Priya (Senior)</div>
                    <div className="text-[10px] text-slate-500 truncate">Full Stack</div>
                  </button>
                </div>
              </div>
            </form>
          )}

          {mode === 'signup' && (
            <form onSubmit={handleSignupSubmit} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 mb-1">
                  <UserIcon className="w-3.5 h-3.5 text-lime-600" />
                  Candidate Full Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Rahul Verma"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-lime-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 mb-1">
                  <Mail className="w-3.5 h-3.5 text-lime-600" />
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  placeholder="rahul.verma@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-lime-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 mb-1">
                  <Briefcase className="w-3.5 h-3.5 text-lime-600" />
                  Target Job Role
                </label>
                <select
                  value={targetRole}
                  onChange={(e) => setTargetRole(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-lime-500 focus:outline-hidden"
                >
                  <option value="Frontend Developer">Frontend Developer</option>
                  <option value="Full Stack Engineer">Full Stack Engineer</option>
                  <option value="Backend Engineer">Backend Engineer</option>
                  <option value="Machine Learning Engineer">Machine Learning Engineer</option>
                  <option value="DevOps / SRE">DevOps / SRE</option>
                  <option value="Product Manager">Product Manager</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 mb-1">
                  <Lock className="w-3.5 h-3.5 text-lime-600" />
                  Password
                </label>
                <input
                  type="password"
                  placeholder="Create password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-lime-500 focus:outline-hidden"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-lime-600 to-emerald-600 hover:from-lime-700 hover:to-emerald-700 text-white font-bold text-xs shadow-md shadow-lime-600/20 transition-all flex items-center justify-center gap-2 mt-2"
              >
                <UserPlus className="w-4 h-4" />
                <span>Register & Launch Practice</span>
              </button>
            </form>
          )}

          {mode === 'switch' && (
            <div className="space-y-3">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block mb-1">
                Active & Saved Candidate Profiles:
              </span>
              <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                {usersList.map((u) => {
                  const isCurrent = u.id === currentUser.id && isLoggedIn;
                  return (
                    <div
                      key={u.id}
                      onClick={() => { switchUser(u.id); setIsAuthModalOpen(false); }}
                      className={`flex items-center gap-3 p-3 rounded-2xl border cursor-pointer transition-all ${
                        isCurrent
                          ? 'border-sky-500 bg-sky-50/70 dark:bg-sky-950/40'
                          : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                      }`}
                    >
                      <img
                        src={u.avatar}
                        alt={u.name}
                        className="w-9 h-9 rounded-full object-cover border border-sky-300"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                            {u.name}
                          </p>
                          {isCurrent && (
                            <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-sky-100 text-sky-800 dark:bg-sky-900 dark:text-sky-300">
                              Active
                            </span>
                          )}
                        </div>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                          {u.email} • {u.targetRole}
                        </p>
                      </div>
                      {isCurrent && <Check className="w-4 h-4 text-sky-600 dark:text-sky-400" />}
                    </div>
                  );
                })}
              </div>

              {isLoggedIn && (
                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-end">
                  <button
                    onClick={() => { logout(); setIsAuthModalOpen(false); }}
                    className="text-xs font-semibold text-rose-600 dark:text-rose-400 hover:underline"
                  >
                    Log Out of Current Session
                  </button>
                </div>
              )}
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
