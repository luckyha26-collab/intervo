import React, { useState } from 'react';
import {
  Sparkles,
  Mic,
  ShieldCheck,
  Moon,
  Sun,
  WifiOff,
  History,
  TrendingUp,
  Users,
  Compass,
  PlayCircle,
  Brain,
  Radio,
  LogIn,
  UserCheck
} from 'lucide-react';
import { useApp, ActiveTab } from '../context/AppContext';
import { VoiceCommandsModal } from './VoiceCommandsModal';
import { EncryptionVaultModal } from './EncryptionVaultModal';
import { AuthModal } from './AuthModal';

export const Navbar: React.FC = () => {
  const {
    currentUser,
    isLoggedIn,
    darkMode,
    toggleDarkMode,
    isOnline,
    currentTab,
    setCurrentTab,
    activeSession,
    lastVoiceCommand,
    isVaultEncrypted,
    setIsAuthModalOpen
  } = useApp();

  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const [isVaultModalOpen, setIsVaultModalOpen] = useState(false);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Compass },
    { id: 'setup', label: 'Practice Mock', icon: PlayCircle },
    ...(activeSession ? [{ id: 'room', label: 'Live Interview', icon: Mic, highlight: true }] : []),
    { id: 'weaknesses', label: 'Weakness Detector', icon: Brain, badge: 'NEW' },
    { id: 'gd-room', label: 'GD Call Arena', icon: Radio, badge: 'LIVE' },
    { id: 'collaborative', label: 'Peer Studio', icon: Users },
    { id: 'analytics', label: 'Analytics', icon: TrendingUp },
    { id: 'history', label: 'History', icon: History }
  ];

  return (
    <>
      <header className="sticky top-0 z-40 w-full border-b border-sky-100 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            
            {/* Brand Logo in White, Light Blue & Olive */}
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => setCurrentTab('dashboard')}>
              <div className="relative flex items-center justify-center w-10 h-10 rounded-2xl bg-gradient-to-br from-sky-400 via-sky-500 to-lime-500 text-white shadow-md shadow-sky-500/20">
                <Sparkles className="w-5 h-5 animate-pulse" />
                <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-lime-500 border-2 border-white dark:border-slate-900 rounded-full"></span>
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-base font-extrabold tracking-tight bg-gradient-to-r from-sky-600 via-sky-700 to-lime-700 dark:from-sky-400 dark:via-sky-300 dark:to-lime-400 bg-clip-text text-transparent">
                    PrepVertex AI
                  </span>
                  <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded-md bg-lime-100 text-lime-800 dark:bg-lime-950 dark:text-lime-300 border border-lime-300">
                    GD & COACH PRO
                  </span>
                </div>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 font-medium">
                  AI Mock Interview Coach • GD Arena • Weakness Detector
                </p>
              </div>
            </div>

            {/* Navigation Tabs (Desktop) */}
            <nav className="hidden lg:flex items-center gap-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setCurrentTab(item.id as ActiveTab)}
                    className={`relative flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                      isActive
                        ? 'bg-sky-50 text-sky-700 dark:bg-sky-950/70 dark:text-sky-300 font-bold shadow-xs'
                        : item.highlight
                        ? 'text-rose-600 dark:text-rose-400 bg-rose-50/70 dark:bg-rose-950/40 hover:bg-rose-100 animate-pulse'
                        : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{item.label}</span>
                    {item.badge && (
                      <span className="text-[9px] font-black px-1.5 py-0.2 rounded-full bg-lime-500 text-white leading-tight">
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>

            {/* Right Quick Controls */}
            <div className="flex items-center gap-2">
              
              {/* Offline indicator */}
              {!isOnline && (
                <div
                  className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/10 text-amber-700 dark:text-amber-300 border border-amber-500/30 text-xs font-medium"
                  title="Offline mode active - local practice available"
                >
                  <WifiOff className="w-3.5 h-3.5" />
                  <span>Offline Ready</span>
                </div>
              )}

              {/* Hands-free Voice Commands Button */}
              <button
                onClick={() => setIsVoiceModalOpen(true)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-sky-200 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-300 hover:bg-sky-50 dark:hover:bg-slate-800 transition-colors"
                title="Hands-free Voice Commands"
              >
                <Mic className="w-3.5 h-3.5 text-sky-500 animate-pulse" />
                <span className="hidden xl:inline text-[11px] font-bold">Voice Commands</span>
              </button>

              {/* E2E Encryption Badge */}
              <button
                onClick={() => setIsVaultModalOpen(true)}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs transition-colors ${
                  isVaultEncrypted
                    ? 'border-lime-300 bg-lime-50/60 dark:bg-lime-950/30 text-lime-800 dark:text-lime-300'
                    : 'border-slate-300 dark:border-slate-700 text-slate-500'
                }`}
                title="End-to-End Encryption status"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-lime-600" />
                <span className="hidden sm:inline text-[11px] font-bold">AES-256 E2E</span>
              </button>

              {/* Dark / Light Toggle */}
              <button
                onClick={toggleDarkMode}
                className="p-2 rounded-xl text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
              >
                {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
              </button>

              {/* User Profile / Login & Signup Trigger */}
              {isLoggedIn ? (
                <button
                  onClick={() => setIsAuthModalOpen(true)}
                  className="flex items-center gap-2 pl-2 pr-3 py-1 rounded-2xl border border-sky-200 dark:border-slate-700 bg-sky-50/50 dark:bg-slate-800/80 hover:bg-sky-100/70 transition-all text-left"
                  title="Switch Candidate Profile or View Account"
                >
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    className="w-7 h-7 rounded-full border border-sky-400 object-cover"
                  />
                  <div className="hidden sm:block">
                    <p className="text-xs font-bold text-slate-900 dark:text-white leading-tight">
                      {currentUser.name}
                    </p>
                    <p className="text-[10px] text-sky-700 dark:text-sky-300 leading-tight truncate max-w-[100px]">
                      {currentUser.targetRole}
                    </p>
                  </div>
                </button>
              ) : (
                <button
                  onClick={() => setIsAuthModalOpen(true)}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-sky-500 hover:bg-sky-600 text-white text-xs font-bold shadow-xs transition-all"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>Log In / Sign Up</span>
                </button>
              )}

            </div>
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="flex lg:hidden items-center justify-around border-t border-sky-100 dark:border-slate-800 px-2 py-1.5 bg-slate-50/90 dark:bg-slate-900/90 overflow-x-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentTab(item.id as ActiveTab)}
                className={`flex flex-col items-center py-1 px-2 rounded-lg text-[10px] font-medium whitespace-nowrap ${
                  isActive
                    ? 'text-sky-600 dark:text-sky-400 font-bold'
                    : 'text-slate-500 dark:text-slate-400'
                }`}
              >
                <Icon className="w-3.5 h-3.5 mb-0.5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* Voice Command feedback toast banner */}
        {lastVoiceCommand && (
          <div className="bg-sky-600 text-white px-4 py-1.5 text-xs text-center font-medium animate-bounce flex items-center justify-center gap-2">
            <Mic className="w-3.5 h-3.5" />
            <span>Voice command recognized: <strong>"{lastVoiceCommand}"</strong></span>
          </div>
        )}
      </header>

      {/* Modals */}
      <VoiceCommandsModal isOpen={isVoiceModalOpen} onClose={() => setIsVoiceModalOpen(false)} />
      <EncryptionVaultModal isOpen={isVaultModalOpen} onClose={() => setIsVaultModalOpen(false)} />
      <AuthModal />
    </>
  );
};
