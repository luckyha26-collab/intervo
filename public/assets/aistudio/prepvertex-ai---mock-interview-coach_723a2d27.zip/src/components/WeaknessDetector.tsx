import React, { useState } from 'react';
import {
  AlertTriangle,
  Target,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  TrendingUp,
  Brain,
  ShieldAlert,
  Zap,
  Play,
  RotateCcw,
  Layers,
  HelpCircle
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const WeaknessDetector: React.FC = () => {
  const { weaknessTopics, practiceWeakness, resolveWeakness, currentUser, userSessions } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState<string>('');

  const categories = ['All', 'System Architecture', 'Algorithms & Data Structures', 'Behavioral & Leadership', 'Database & Storage', 'DevOps & Reliability', 'Frontend Performance'];

  const filtered = weaknessTopics.filter(w => {
    const matchCat = selectedCategory === 'All' || w.category === selectedCategory;
    const matchSearch = w.topic.toLowerCase().includes(searchTerm.toLowerCase()) || w.diagnosis.toLowerCase().includes(searchTerm.toLowerCase());
    return matchCat && matchSearch;
  });

  const criticalCount = weaknessTopics.filter(w => w.severity === 'Critical').length;
  const avgRecovery = Math.round(weaknessTopics.reduce((acc, w) => acc + w.recoveryProgress, 0) / weaknessTopics.length);

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-12 animate-fade-in">
      
      {/* Top Header Card in White & Glacier Light Blue with Olive Accents */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-sky-500 via-sky-600 to-teal-700 p-8 sm:p-10 text-white shadow-xl">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-96 h-96 bg-lime-400/20 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-1/3 -mb-10 w-72 h-72 bg-white/20 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 border border-white/30 text-white text-xs font-bold backdrop-blur-xs">
            <Brain className="w-3.5 h-3.5" />
            <span>Feature 14 • AI Weakness Detector & Remediation Engine</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-black text-white leading-tight">
            Identify & Eliminate Technical Interview Weak Spots
          </h1>

          <p className="text-xs sm:text-sm text-sky-100 leading-relaxed max-w-2xl">
            Our Bar Raiser engine analyzes every answer, missing topic, and latency trade-off from your mock sessions for {currentUser.name}. Practice targeted drills to turn vulnerabilities into strengths.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-4 text-xs font-semibold">
            <div className="flex items-center gap-2 bg-white/10 px-3.5 py-1.5 rounded-xl backdrop-blur-xs">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-400 animate-ping"></span>
              <span>{criticalCount} Critical Gaps Identified</span>
            </div>
            <div className="flex items-center gap-2 bg-white/10 px-3.5 py-1.5 rounded-xl backdrop-blur-xs">
              <span className="w-2.5 h-2.5 rounded-full bg-lime-300"></span>
              <span>{avgRecovery}% Average Recovery Progress</span>
            </div>
            <div className="flex items-center gap-2 bg-white/10 px-3.5 py-1.5 rounded-xl backdrop-blur-xs">
              <span>{userSessions.length} Sessions Scanned</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Category Pills */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-sky-100 dark:border-slate-800 shadow-xs">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-sky-500 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <input
          type="text"
          placeholder="Search weakness topics (e.g. cache, STAR, index)..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-sky-500 focus:outline-hidden min-w-[240px]"
        />
      </div>

      {/* Weakness Topic Cards Grid */}
      <div className="space-y-4">
        {filtered.map((item) => {
          const isCritical = item.severity === 'Critical';
          const isHigh = item.severity === 'High';

          const badgeClass = isCritical
            ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300 border-rose-200'
            : isHigh
            ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300 border-amber-200'
            : 'bg-lime-100 text-lime-800 dark:bg-lime-950 dark:text-lime-300 border-lime-200';

          return (
            <div
              key={item.id}
              className="bg-white dark:bg-slate-900 rounded-3xl border border-sky-100 dark:border-slate-800 p-6 shadow-sm hover:border-sky-300 dark:hover:border-sky-700 transition-all space-y-4"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className={`p-2.5 rounded-2xl ${isCritical ? 'bg-rose-50 text-rose-600' : isHigh ? 'bg-amber-50 text-amber-600' : 'bg-lime-50 text-lime-700'}`}>
                    <ShieldAlert className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                        {item.topic}
                      </h3>
                      <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${badgeClass}`}>
                        {item.severity} Gap
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      Category: {item.category} • Detected in {item.frequencyDetected} past answer evaluations
                    </p>
                  </div>
                </div>

                {/* Practice Now CTA */}
                <button
                  onClick={() => practiceWeakness(item.id)}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-sky-500 to-sky-600 hover:from-sky-600 hover:to-sky-700 text-white font-bold text-xs shadow-md shadow-sky-500/20 flex items-center justify-center gap-1.5 transition-all self-start sm:self-center"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Practice This Weakness</span>
                </button>
              </div>

              {/* Diagnosis & Suggested Action Box */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 pt-1">
                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700 space-y-1">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />
                    AI Bar Raiser Diagnosis
                  </span>
                  <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                    {item.diagnosis}
                  </p>
                </div>

                <div className="p-3.5 rounded-2xl bg-lime-50/60 dark:bg-lime-950/20 border border-lime-200/80 dark:border-lime-900/40 space-y-1">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-lime-800 dark:text-lime-300 flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 text-lime-600" />
                    Prescribed Action Item
                  </span>
                  <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                    {item.suggestedAction}
                  </p>
                </div>
              </div>

              {/* Sample Target Question & Recovery Progress Bar */}
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div className="text-slate-600 dark:text-slate-300 flex items-center gap-1.5 max-w-xl truncate">
                  <HelpCircle className="w-4 h-4 text-sky-500 shrink-0" />
                  <span className="truncate italic">"{item.sampleQuestionPrompt}"</span>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-bold text-slate-500">Recovery:</span>
                    <div className="w-24 bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        style={{ width: `${item.recoveryProgress}%` }}
                        className="bg-lime-500 h-full rounded-full transition-all"
                      ></div>
                    </div>
                    <span className="text-[11px] font-mono font-bold text-slate-800 dark:text-slate-200">
                      {item.recoveryProgress}%
                    </span>
                  </div>

                  <button
                    onClick={() => resolveWeakness(item.id)}
                    className="text-[11px] font-semibold text-lime-700 dark:text-lime-400 hover:underline"
                  >
                    + Boost Progress
                  </button>
                </div>
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};
