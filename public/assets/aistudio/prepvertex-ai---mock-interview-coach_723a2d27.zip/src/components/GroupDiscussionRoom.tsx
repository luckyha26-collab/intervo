import React, { useState, useEffect } from 'react';
import {
  Users,
  Mic,
  MicOff,
  Hand,
  PhoneOff,
  Share2,
  Copy,
  Check,
  MessageSquare,
  Award,
  Sparkles,
  ShieldCheck,
  Send,
  Volume2,
  Clock,
  ThumbsUp,
  UserPlus,
  PlayCircle
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const GroupDiscussionRoom: React.FC = () => {
  const {
    activeGDRoom,
    gdMessages,
    isGDCallActive,
    isUserMuted,
    hasUserRaisedHand,
    toggleGDMute,
    toggleGDRaiseHand,
    startGDCall,
    leaveGDCall,
    sendGDMessage,
    gdScorecard,
    concludeGDAndGenerateScorecard,
    setGdScorecard,
    currentUser
  } = useApp();

  const [copiedInvite, setCopiedInvite] = useState(false);
  const [chatDraft, setChatDraft] = useState('');
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [callTimer, setCallTimer] = useState(activeGDRoom.callDurationSec);

  // Call timer increment
  useEffect(() => {
    if (!isGDCallActive) return;
    const interval = setInterval(() => {
      setCallTimer(prev => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [isGDCallActive]);

  const handleCopyLink = () => {
    const inviteUrl = `${window.location.origin}#gd-invite=${activeGDRoom.inviteCode}`;
    navigator.clipboard.writeText(inviteUrl);
    setCopiedInvite(true);
    setTimeout(() => setCopiedInvite(false), 2000);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatDraft.trim()) return;
    sendGDMessage(chatDraft.trim());
    setChatDraft('');
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12 animate-fade-in">
      
      {/* Top Banner with Invite & Status */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-sky-100 dark:border-slate-800 p-6 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-lime-50 text-lime-800 dark:bg-lime-950/50 dark:text-lime-300 border border-lime-200 text-xs font-bold">
              <span className="w-2 h-2 rounded-full bg-lime-500 animate-ping"></span>
              Live Multi-Participant GD Call
            </span>
            <span className="text-xs text-slate-400 font-mono">Code: {activeGDRoom.inviteCode}</span>
          </div>
          <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white">
            {activeGDRoom.title}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Topic: {activeGDRoom.topicDescription}
          </p>
        </div>

        {/* Invite & Call Duration */}
        <div className="flex items-center gap-2.5 self-end md:self-center shrink-0">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-mono font-bold text-slate-700 dark:text-slate-300">
            <Clock className="w-3.5 h-3.5 text-sky-500" />
            <span>{formatTime(callTimer)}</span>
          </div>

          <button
            onClick={handleCopyLink}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl border border-sky-200 dark:border-sky-800 bg-sky-50 dark:bg-sky-950/50 text-sky-700 dark:text-sky-300 text-xs font-bold hover:bg-sky-100 transition-colors"
          >
            {copiedInvite ? <Check className="w-3.5 h-3.5 text-lime-600" /> : <Copy className="w-3.5 h-3.5 text-sky-500" />}
            <span>{copiedInvite ? 'Invite Copied!' : 'Copy Call Invite Link'}</span>
          </button>

          <button
            onClick={() => setShowInviteModal(true)}
            className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 transition-colors"
            title="Invite Peers into Call"
          >
            <UserPlus className="w-4 h-4 text-lime-600" />
          </button>
        </div>
      </div>

      {!gdScorecard ? (
        /* Active GD Call Arena Grid */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Left: Video & Voice Speaker Tiles */}
          <div className="lg:col-span-8 space-y-4">
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              {/* Current User Video Tile */}
              <div className="relative bg-gradient-to-br from-slate-900 to-slate-950 rounded-3xl overflow-hidden border-2 border-sky-400 shadow-md p-5 flex flex-col justify-between min-h-[220px]">
                <div className="flex items-center justify-between z-10">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-sky-500 text-white">
                    You (Candidate)
                  </span>
                  {hasUserRaisedHand && (
                    <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-400 text-amber-950 animate-bounce">
                      <Hand className="w-3 h-3" /> Hand Raised
                    </span>
                  )}
                </div>

                <div className="flex flex-col items-center justify-center py-4 z-10">
                  <div className={`relative p-1 rounded-full border-4 transition-all ${!isUserMuted ? 'border-sky-400 shadow-lg shadow-sky-500/30' : 'border-slate-700'}`}>
                    <img
                      src={currentUser.avatar}
                      alt={currentUser.name}
                      className="w-16 h-16 rounded-full object-cover"
                    />
                    {!isUserMuted && (
                      <span className="absolute bottom-0 right-0 w-5 h-5 bg-lime-500 rounded-full border-2 border-slate-900 flex items-center justify-center">
                        <span className="w-2 h-2 bg-white rounded-full animate-ping"></span>
                      </span>
                    )}
                  </div>
                  <h4 className="font-extrabold text-sm text-white mt-2">
                    {currentUser.name}
                  </h4>
                  <p className="text-[11px] text-sky-200">
                    {currentUser.targetRole}
                  </p>
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-300 z-10 pt-2 border-t border-slate-800">
                  <span className="flex items-center gap-1">
                    {isUserMuted ? <MicOff className="w-3.5 h-3.5 text-rose-400" /> : <Mic className="w-3.5 h-3.5 text-lime-400" />}
                    <span>{isUserMuted ? 'Microphone Muted' : 'Speaking live'}</span>
                  </span>
                  <span className="font-mono text-slate-400">Time: 42s</span>
                </div>
              </div>

              {/* Other Call Participants */}
              {activeGDRoom.participants.map((p) => (
                <div
                  key={p.id}
                  className={`relative bg-gradient-to-br from-slate-800 to-slate-900 rounded-3xl overflow-hidden border p-5 flex flex-col justify-between min-h-[220px] transition-all ${
                    p.isSpeaking ? 'border-lime-400 shadow-md shadow-lime-500/20' : 'border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between z-10">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${p.isAI ? 'bg-sky-600 text-white' : 'bg-slate-700 text-slate-200'}`}>
                      {p.isAI ? 'AI Bar Raiser Moderator' : 'Peer Candidate'}
                    </span>
                    {p.hasRaisedHand && (
                      <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-400 text-amber-950">
                        <Hand className="w-3 h-3" /> Hand Raised
                      </span>
                    )}
                  </div>

                  <div className="flex flex-col items-center justify-center py-4 z-10">
                    <div className={`relative p-1 rounded-full border-4 transition-all ${p.isSpeaking ? 'border-lime-400' : 'border-slate-600'}`}>
                      <img
                        src={p.avatar}
                        alt={p.name}
                        className="w-16 h-16 rounded-full object-cover"
                      />
                      {p.isSpeaking && (
                        <span className="absolute bottom-0 right-0 w-5 h-5 bg-lime-500 rounded-full border-2 border-slate-900 flex items-center justify-center">
                          <span className="w-2 h-2 bg-white rounded-full animate-ping"></span>
                        </span>
                      )}
                    </div>
                    <h4 className="font-extrabold text-sm text-white mt-2">
                      {p.name}
                    </h4>
                    <p className="text-[11px] text-slate-300">
                      {p.role}
                    </p>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-300 z-10 pt-2 border-t border-slate-800">
                    <span className="flex items-center gap-1">
                      {p.isMuted ? <MicOff className="w-3.5 h-3.5 text-slate-500" /> : <Mic className="w-3.5 h-3.5 text-lime-400" />}
                      <span>{p.isSpeaking ? 'Speaking...' : p.isMuted ? 'Muted' : 'Listening'}</span>
                    </span>
                    <span className="font-mono text-slate-400">Time: {p.speakingTimeSec}s</span>
                  </div>
                </div>
              ))}

            </div>

            {/* Bottom Call Controls Dock */}
            <div className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-sky-100 dark:border-slate-800 shadow-sm flex flex-wrap items-center justify-between gap-3">
              
              <div className="flex items-center gap-2">
                <button
                  onClick={toggleGDMute}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all ${
                    isUserMuted
                      ? 'bg-rose-50 text-rose-700 dark:bg-rose-950/50 dark:text-rose-300 border border-rose-300'
                      : 'bg-lime-50 text-lime-800 dark:bg-lime-950/50 dark:text-lime-300 border border-lime-300 shadow-xs'
                  }`}
                >
                  {isUserMuted ? <MicOff className="w-4 h-4 text-rose-600" /> : <Mic className="w-4 h-4 text-lime-600" />}
                  <span>{isUserMuted ? 'Unmute Mic' : 'Mute Microphone'}</span>
                </button>

                <button
                  onClick={toggleGDRaiseHand}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all border ${
                    hasUserRaisedHand
                      ? 'bg-amber-100 text-amber-900 border-amber-300 dark:bg-amber-950/50 dark:text-amber-300'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200'
                  }`}
                >
                  <Hand className="w-4 h-4 text-amber-500" />
                  <span>{hasUserRaisedHand ? 'Lower Hand' : 'Raise Hand'}</span>
                </button>
              </div>

              {/* End / Conclude GD Round */}
              <div className="flex items-center gap-2">
                <button
                  onClick={concludeGDAndGenerateScorecard}
                  className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-sky-500 to-sky-600 hover:from-sky-600 hover:to-sky-700 text-white font-bold text-xs shadow-md shadow-sky-500/20 flex items-center gap-2"
                >
                  <Award className="w-4 h-4 text-lime-300" />
                  <span>Conclude Round & Get GD Scorecard</span>
                </button>

                <button
                  onClick={leaveGDCall}
                  className="p-2.5 rounded-2xl bg-rose-500 text-white hover:bg-rose-600 transition-colors"
                  title="Leave GD Call"
                >
                  <PhoneOff className="w-4 h-4" />
                </button>
              </div>

            </div>

          </div>

          {/* Right: Live Transcript & GD Speech Stream */}
          <div className="lg:col-span-4 bg-white dark:bg-slate-900 rounded-3xl border border-sky-100 dark:border-slate-800 p-5 shadow-sm flex flex-col justify-between min-h-[480px]">
            
            <div>
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-sky-500" />
                  <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">
                    Live Discussion Transcript
                  </h3>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-lime-100 text-lime-800">
                  Moderated
                </span>
              </div>

              <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1">
                {gdMessages.map((msg) => {
                  const isMod = msg.type === 'moderator';
                  const isMe = msg.senderId === currentUser.id;

                  return (
                    <div
                      key={msg.id}
                      className={`p-3 rounded-2xl text-xs space-y-1 ${
                        isMod
                          ? 'bg-sky-50/70 dark:bg-sky-950/40 border border-sky-200/80 dark:border-sky-800'
                          : isMe
                          ? 'bg-lime-50/60 dark:bg-lime-950/40 border border-lime-200/80 dark:border-lime-900'
                          : 'bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <img
                            src={msg.avatar}
                            alt={msg.senderName}
                            className="w-4 h-4 rounded-full object-cover"
                          />
                          <span className="font-bold text-slate-900 dark:text-white">
                            {msg.senderName}
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-400">{msg.timestamp}</span>
                      </div>
                      <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                        {msg.text}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Quick Discussion Input Form */}
            <form onSubmit={handleSendMessage} className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
              <div className="flex gap-1.5">
                <input
                  type="text"
                  value={chatDraft}
                  onChange={(e) => setChatDraft(e.target.value)}
                  placeholder="Speak your point or type argument..."
                  className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                />
                <button
                  type="submit"
                  disabled={!chatDraft.trim()}
                  className="px-4 py-2.5 rounded-xl bg-sky-500 text-white font-bold text-xs hover:bg-sky-600 disabled:opacity-50 transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </form>

          </div>

        </div>
      ) : (
        /* Post-GD Performance Scorecard */
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-sky-100 dark:border-slate-800 p-8 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100 dark:border-slate-800">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-lime-100 text-lime-800 dark:bg-lime-950 dark:text-lime-300 text-xs font-bold mb-2">
                <Award className="w-3.5 h-3.5" />
                <span>AI Bar Raiser GD Evaluation Generated</span>
              </div>
              <h3 className="text-2xl font-black text-slate-900 dark:text-white">
                Group Discussion Assessment for {currentUser.name}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Topic: {activeGDRoom.title}
              </p>
            </div>

            <div className="flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-sky-500 to-lime-500 text-white font-black text-3xl shadow-lg shadow-sky-500/20 shrink-0">
              {gdScorecard.totalScore}
              <span className="text-xs font-normal opacity-80">/10</span>
            </div>
          </div>

          {/* 4 Core Competency Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: 'Leadership & Initiative', score: gdScorecard.leadershipScore },
              { label: 'Articulation & Clarity', score: gdScorecard.clarityScore },
              { label: 'Listening & Rebuttal Etiquette', score: gdScorecard.listeningEtiquette },
              { label: 'Technical Knowledge Depth', score: gdScorecard.knowledgeScore }
            ].map((c, idx) => (
              <div key={idx} className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-center">
                <div className="text-xl font-black text-slate-900 dark:text-white">
                  {c.score}/10
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  {c.label}
                </div>
              </div>
            ))}
          </div>

          {/* Feedback narrative */}
          <div className="p-4 rounded-2xl bg-sky-50/70 dark:bg-sky-950/30 border border-sky-100 dark:border-sky-900 text-xs sm:text-sm text-sky-900 dark:text-sky-200 leading-relaxed italic">
            "{gdScorecard.feedback}"
          </div>

          {/* Key points & improvements */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-2xl bg-lime-50/60 dark:bg-lime-950/20 border border-lime-200 dark:border-lime-900/40 space-y-2">
              <span className="text-xs font-bold text-lime-800 dark:text-lime-300 flex items-center gap-1.5">
                <Check className="w-4 h-4 text-lime-600" />
                Strong Contributions Made:
              </span>
              <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                {gdScorecard.keyPointsSpoken.map((pt, idx) => (
                  <li key={idx}>• {pt}</li>
                ))}
              </ul>
            </div>

            <div className="p-4 rounded-2xl bg-rose-50/60 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/40 space-y-2">
              <span className="text-xs font-bold text-rose-800 dark:text-rose-300 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-rose-600" />
                Moderator Recommendations:
              </span>
              <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                {gdScorecard.improvements.map((imp, idx) => (
                  <li key={idx}>• {imp}</li>
                ))}
              </ul>
            </div>
          </div>

          <div className="pt-2 flex justify-end gap-3">
            <button
              onClick={() => startGDCall()}
              className="px-5 py-2.5 rounded-xl bg-sky-500 text-white font-bold text-xs hover:bg-sky-600 shadow-md shadow-sky-500/20"
            >
              Start Another GD Call
            </button>
          </div>
        </div>
      )}

      {/* Invite Modal */}
      {showInviteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-sky-100 dark:border-slate-800 rounded-3xl w-full max-w-md p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                Invite Friends to Group Discussion
              </h3>
              <button
                onClick={() => setShowInviteModal(false)}
                className="text-slate-400 hover:text-slate-600 text-sm"
              >
                ✕
              </button>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300">
              Share this invite code or link with your study group or peer candidates to join the round table live.
            </p>
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono text-xs text-slate-800 dark:text-slate-200 select-all">
              Invite Code: <strong>{activeGDRoom.inviteCode}</strong>
            </div>
            <button
              onClick={handleCopyLink}
              className="w-full py-2.5 rounded-xl bg-sky-500 text-white font-bold text-xs hover:bg-sky-600 flex items-center justify-center gap-2"
            >
              {copiedInvite ? <Check className="w-4 h-4 text-lime-300" /> : <Copy className="w-4 h-4" />}
              <span>{copiedInvite ? 'Copied to Clipboard!' : 'Copy Direct Call Invite Link'}</span>
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
