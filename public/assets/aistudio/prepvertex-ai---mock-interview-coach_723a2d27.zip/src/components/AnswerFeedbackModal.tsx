import React from 'react';
import {
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
  Award,
  ArrowRight,
  TrendingUp,
  X
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const AnswerFeedbackModal: React.FC = () => {
  const { viewingFeedback, setViewingFeedback, proceedToNextQuestion, activeSession, currentQuestionIndex } = useApp();

  if (!viewingFeedback || !activeSession) return null;

  const score = viewingFeedback.score;
  const isLastQuestion = currentQuestionIndex >= activeSession.questions.length - 1;

  // Score color badge
  const getScoreBadge = (sc: number) => {
    if (sc >= 8) return { bg: 'bg-lime-50 text-lime-800 dark:bg-lime-950 dark:text-lime-300 border-lime-300', label: 'Strong Hire / Staff Standard' };
    if (sc >= 6) return { bg: 'bg-sky-50 text-sky-800 dark:bg-sky-950 dark:text-sky-300 border-sky-300', label: 'Competitive / Borderline Hire' };
    return { bg: 'bg-rose-50 text-rose-800 dark:bg-rose-950 dark:text-rose-300 border-rose-300', label: 'Needs Targeted Practice' };
  };

  const badge = getScoreBadge(score);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white dark:bg-slate-900 border border-sky-100 dark:border-slate-800 rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        
        {/* Header */}
        <div className="p-6 border-b border-sky-100 dark:border-slate-800 bg-gradient-to-r from-sky-50 via-white to-lime-50 dark:from-slate-900 dark:via-slate-800/60 dark:to-slate-900 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-br from-sky-500 to-lime-500 text-white font-black text-xl shadow-md shadow-sky-500/20">
              {score}
              <span className="text-xs font-normal opacity-80">/10</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                  Instant Answer Evaluation
                </h3>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${badge.bg}`}>
                  {badge.label}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Question {currentQuestionIndex + 1} of {activeSession.questions.length} • {activeSession.targetRole}
              </p>
            </div>
          </div>

          <button
            onClick={() => setViewingFeedback(null)}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-6 space-y-6 overflow-y-auto">
          
          {/* Summary Quote */}
          {viewingFeedback.feedbackSummary && (
            <div className="p-4 rounded-2xl bg-sky-50/70 dark:bg-sky-950/30 border border-sky-100 dark:border-sky-900 text-xs text-slate-700 dark:text-slate-300 italic leading-relaxed">
              "{viewingFeedback.feedbackSummary}"
            </div>
          )}

          {/* Key Competencies Grid */}
          {viewingFeedback.keyCompetencyScores && (
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-sky-500" />
                Competency Breakdown
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {[
                  { label: 'Technical Depth', val: viewingFeedback.keyCompetencyScores.technicalDepth },
                  { label: 'Communication', val: viewingFeedback.keyCompetencyScores.communication },
                  { label: 'Problem Solving', val: viewingFeedback.keyCompetencyScores.problemSolving },
                  { label: 'Relevance', val: viewingFeedback.keyCompetencyScores.relevance }
                ].map((comp, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-2xl border border-sky-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 text-center"
                  >
                    <div className="text-sm font-black text-slate-900 dark:text-white">
                      {comp.val || 7}/10
                    </div>
                    <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                      {comp.label}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Strengths & What Was Missing Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Strengths */}
            <div className="space-y-2.5 p-4 rounded-2xl bg-lime-50/60 dark:bg-lime-950/20 border border-lime-200 dark:border-lime-900/40">
              <div className="flex items-center gap-1.5 text-xs font-bold text-lime-800 dark:text-lime-300">
                <CheckCircle2 className="w-4 h-4 text-lime-600 dark:text-lime-400 shrink-0" />
                <span>What Was Done Well (Strengths)</span>
              </div>
              <ul className="space-y-2 text-xs text-slate-700 dark:text-slate-300">
                {viewingFeedback.strengths.map((str, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-lime-600 font-bold">•</span>
                    <span>{str}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Areas to Improve */}
            <div className="space-y-2.5 p-4 rounded-2xl bg-rose-50/60 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/40">
              <div className="flex items-center gap-1.5 text-xs font-bold text-rose-800 dark:text-rose-300">
                <AlertTriangle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />
                <span>What Was Missing / Areas to Improve</span>
              </div>
              <ul className="space-y-2 text-xs text-slate-700 dark:text-slate-300">
                {viewingFeedback.missingAreas.map((gap, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-rose-500 font-bold">•</span>
                    <span>{gap}</span>
                  </li>
                ))}
              </ul>
            </div>

          </div>

          {/* Exemplary Ideal Answer Model */}
          {viewingFeedback.idealAnswerModel && (
            <div className="space-y-2 p-4 rounded-2xl bg-sky-50/70 dark:bg-sky-950/20 border border-sky-200/80 dark:border-sky-900/40">
              <div className="flex items-center gap-1.5 text-xs font-bold text-sky-900 dark:text-sky-300">
                <Lightbulb className="w-4 h-4 text-amber-500 shrink-0" />
                <span>Exemplary Model Answer (STAR / Architecture Framework)</span>
              </div>
              <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-normal">
                {viewingFeedback.idealAnswerModel}
              </p>
            </div>
          )}

        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <button
            onClick={() => setViewingFeedback(null)}
            className="px-4 py-2 text-xs font-semibold rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
          >
            Review My Draft
          </button>

          <button
            onClick={proceedToNextQuestion}
            className="px-6 py-2.5 rounded-2xl bg-sky-500 hover:bg-sky-600 text-white font-extrabold text-xs shadow-md shadow-sky-500/20 flex items-center gap-2 transition-all transform hover:translate-x-0.5"
          >
            <span>{isLastQuestion ? 'Complete Interview & View Summary' : 'Proceed to Next Question'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
