import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import {
  Award,
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
  Download,
  Share2,
  RotateCcw,
  TrendingUp,
  FileText,
  ChevronDown,
  ChevronUp,
  ShieldCheck,
  Sparkles,
  Brain,
  Radio,
  StopCircle
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const SessionSummary: React.FC = () => {
  const { activeSession, setCurrentTab, userSessions } = useApp();
  const [expandedIndex, setExpandedIndex] = useState<number | null>(0);

  useEffect(() => {
    // Trigger celebratory confetti on high performance
    if (activeSession && activeSession.overallScore >= 7.0) {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    }
  }, [activeSession]);

  if (!activeSession) return null;

  const score = activeSession.overallScore;
  const answeredQuestions = activeSession.questions.filter(q => q.feedback);

  const getVerdict = (s: number) => {
    if (s >= 8.5) return { text: 'Strong Hire / Staff Standard', color: 'text-lime-700 dark:text-lime-400', badge: 'bg-lime-100 text-lime-800 dark:bg-lime-950 dark:text-lime-300' };
    if (s >= 7.0) return { text: 'Competitive Hire', color: 'text-sky-700 dark:text-sky-400', badge: 'bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300' };
    if (s >= 5.5) return { text: 'Borderline / Developing', color: 'text-amber-700 dark:text-amber-400', badge: 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300' };
    return { text: 'Needs Structured Practice', color: 'text-rose-700 dark:text-rose-400', badge: 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300' };
  };

  const verdict = getVerdict(score);

  // Export JSON Report
  const handleExportJSON = () => {
    const reportData = {
      app: 'PrepVertex AI - Mock Interview Coach',
      sessionId: activeSession.id,
      targetRole: activeSession.targetRole,
      difficulty: activeSession.difficulty,
      categoryFocus: activeSession.categoryFocus,
      overallScore: activeSession.overallScore,
      overallSummary: activeSession.overallSummary,
      wasStoppedEarly: activeSession.wasStoppedEarly || false,
      completedAt: activeSession.completedAt,
      questions: activeSession.questions.map(q => ({
        question: q.question.question,
        userAnswer: q.userAnswer,
        score: q.feedback?.score,
        strengths: q.feedback?.strengths,
        missingAreas: q.feedback?.missingAreas,
        idealAnswer: q.feedback?.idealAnswerModel
      }))
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `interview-report-${activeSession.targetRole.toLowerCase().replace(/\s+/g, '-')}-${activeSession.id.slice(-6)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handlePrintReport = () => {
    window.print();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12 animate-fade-in print:p-0 print:m-0 print:max-w-full">
      
      {/* Top Banner Card in White & Glacier Light Blue & Olive */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-sky-100 dark:border-slate-800 p-8 shadow-sm space-y-6 text-center">
        
        <div className="flex items-center justify-center gap-2">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-lime-50 dark:bg-lime-950/60 text-lime-800 dark:text-lime-300 text-xs font-bold border border-lime-200">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Interview Assessment Report</span>
          </div>
          {activeSession.wasStoppedEarly && (
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 text-amber-800 border border-amber-200 text-xs font-bold">
              <StopCircle className="w-3.5 h-3.5 text-amber-600" />
              <span>Concluded Early (Partial Assessment)</span>
            </div>
          )}
        </div>

        {/* Score & Verdict */}
        <div className="space-y-3">
          <div className="flex items-center justify-center">
            <div className="flex items-center justify-center w-24 h-24 rounded-3xl bg-gradient-to-br from-sky-400 via-sky-500 to-lime-500 text-white font-black text-4xl shadow-xl shadow-sky-500/20">
              {score}
              <span className="text-base font-normal opacity-80">/10</span>
            </div>
          </div>

          <div>
            <span className={`inline-block px-3 py-1 text-xs font-bold rounded-full ${verdict.badge} mb-2`}>
              Verdict: {verdict.text}
            </span>
            <h2 className="text-2xl font-black text-slate-900 dark:text-white">
              {activeSession.targetRole} Evaluation
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Difficulty: {activeSession.difficulty} • {answeredQuestions.length} of {activeSession.questions.length} Questions Evaluated • {new Date(activeSession.completedAt).toLocaleDateString()}
            </p>
          </div>
        </div>

        {/* Overall Summary Narrative */}
        <div className="p-4 rounded-2xl bg-sky-50/60 dark:bg-slate-800/60 border border-sky-100 dark:border-slate-700 text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed max-w-2xl mx-auto">
          "{activeSession.overallSummary}"
        </div>

        {/* Actions Bar */}
        <div className="pt-2 flex flex-wrap items-center justify-center gap-3 print:hidden">
          <button
            onClick={handleExportJSON}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <Download className="w-4 h-4 text-sky-500" />
            <span>Download JSON Report</span>
          </button>

          <button
            onClick={handlePrintReport}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <FileText className="w-4 h-4 text-lime-600" />
            <span>Printable / PDF Summary</span>
          </button>

          <button
            onClick={() => setCurrentTab('weaknesses')}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-lime-500 hover:bg-lime-400 text-slate-900 text-xs font-bold shadow-md transition-all"
          >
            <Brain className="w-4 h-4 text-slate-900" />
            <span>Check Weakness Detector</span>
          </button>

          <button
            onClick={() => setCurrentTab('setup')}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-sky-500 text-white hover:bg-sky-600 text-xs font-bold transition-all"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Practice Another Session</span>
          </button>
        </div>

      </div>

      {/* Question by Question Detailed Breakdown */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-sky-100 dark:border-slate-800 p-6 sm:p-8 shadow-sm space-y-6">
        
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
              Question-by-Question Deep Dive
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Review answers, bar raiser scores, strengths, and areas to improve
            </p>
          </div>
          <span className="text-xs text-slate-500 dark:text-slate-400 font-bold">
            {answeredQuestions.length} answered items
          </span>
        </div>

        <div className="space-y-4">
          {activeSession.questions.map((item, idx) => {
            const isExpanded = expandedIndex === idx;
            const qScore = item.feedback?.score || (item.userAnswer ? 7 : 0);

            return (
              <div
                key={idx}
                className="border border-sky-100 dark:border-slate-800 rounded-2xl overflow-hidden transition-all"
              >
                {/* Header row */}
                <div
                  onClick={() => setExpandedIndex(isExpanded ? null : idx)}
                  className="p-4 bg-slate-50/70 dark:bg-slate-800/40 hover:bg-sky-50/50 cursor-pointer flex items-center justify-between gap-4 transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="flex items-center justify-center w-7 h-7 rounded-xl bg-sky-100 dark:bg-slate-700 text-sky-800 dark:text-slate-200 font-bold text-xs shrink-0">
                      Q{idx + 1}
                    </span>
                    <p className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate">
                      {item.question.question}
                    </p>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    {item.feedback ? (
                      <span className="text-xs font-black px-2.5 py-1 rounded-xl bg-lime-50 text-lime-800 dark:bg-lime-950 dark:text-lime-300 border border-lime-200">
                        Score: {qScore}/10
                      </span>
                    ) : (
                      <span className="text-xs px-2.5 py-1 rounded-xl bg-slate-100 text-slate-500">
                        Not Answered
                      </span>
                    )}
                    {isExpanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                  </div>
                </div>

                {/* Expanded content */}
                {isExpanded && (
                  <div className="p-5 space-y-4 border-t border-sky-100 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs">
                    
                    {/* Candidate's submitted answer */}
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                        Your Submitted Response:
                      </label>
                      <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700 text-slate-800 dark:text-slate-200 leading-relaxed font-mono text-xs">
                        {item.userAnswer || '(Question skipped / concluded before response)'}
                      </div>
                    </div>

                    {item.feedback && (
                      <>
                        <div className="p-3.5 rounded-2xl bg-sky-50/60 dark:bg-sky-950/20 text-sky-900 dark:text-sky-300 italic border border-sky-100">
                          "{item.feedback.feedbackSummary}"
                        </div>

                        {/* Strengths & Missing Areas */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div className="p-3.5 rounded-2xl bg-lime-50/50 dark:bg-lime-950/20 border border-lime-100 dark:border-lime-900/40">
                            <span className="font-bold text-lime-800 dark:text-lime-300 block mb-1">
                              ✓ What was good:
                            </span>
                            <ul className="space-y-1 text-slate-700 dark:text-slate-300">
                              {item.feedback.strengths.map((str, sIdx) => (
                                <li key={sIdx}>• {str}</li>
                              ))}
                            </ul>
                          </div>

                          <div className="p-3.5 rounded-2xl bg-rose-50/50 dark:bg-rose-950/20 border border-rose-100 dark:border-rose-900/40">
                            <span className="font-bold text-rose-800 dark:text-rose-300 block mb-1">
                              ⚠ What was missing / To improve:
                            </span>
                            <ul className="space-y-1 text-slate-700 dark:text-slate-300">
                              {item.feedback.missingAreas.map((gap, gIdx) => (
                                <li key={gIdx}>• {gap}</li>
                              ))}
                            </ul>
                          </div>
                        </div>

                        {/* Ideal Answer Model */}
                        <div className="p-3.5 rounded-2xl bg-sky-50/50 dark:bg-sky-950/20 border border-sky-100 dark:border-sky-900/40">
                          <span className="font-bold text-sky-900 dark:text-sky-300 block mb-1">
                            💡 Exemplary Benchmark Response:
                          </span>
                          <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                            {item.feedback.idealAnswerModel}
                          </p>
                        </div>
                      </>
                    )}

                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>

    </div>
  );
};
