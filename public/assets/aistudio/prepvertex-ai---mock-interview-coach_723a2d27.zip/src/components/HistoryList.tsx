import React, { useState } from 'react';
import {
  History,
  TrendingUp,
  Trash2,
  Calendar,
  ExternalLink,
  Sparkles,
  Layers,
  Award,
  Filter,
  CheckCircle2,
  Play
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { InterviewSession } from '../types';

export const HistoryList: React.FC = () => {
  const { userSessions, deleteSession, clearAllSessions, viewPastSession, setCurrentTab, currentUser } = useApp();
  const [filterDifficulty, setFilterDifficulty] = useState<string>('All');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const filteredSessions = userSessions.filter(s => {
    if (filterDifficulty === 'All') return true;
    return s.difficulty === filterDifficulty;
  });

  // Calculate score trend metrics
  const scores = userSessions.map(s => s.overallScore).filter(Boolean);
  const avgScore = scores.length > 0 ? (scores.reduce((a, b) => a + b, 0) / scores.length).toFixed(1) : '0.0';
  const highestScore = scores.length > 0 ? Math.max(...scores).toFixed(1) : '0.0';

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-12 animate-fade-in">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-black text-slate-900 dark:text-white">
              Interview History & Progress Tracking
            </h2>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300">
              {currentUser.name}
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Review past mock interviews, track performance gains over time, and manage session records.
          </p>
        </div>

        {userSessions.length > 0 && (
          <button
            onClick={() => {
              if (window.confirm('Are you sure you want to delete all past sessions? This cannot be undone.')) {
                clearAllSessions();
              }
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900/60 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear All History</span>
          </button>
        )}
      </div>

      {/* Progress Tracking Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-medium mb-2">
            <span>Total Sessions Completed</span>
            <Layers className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white">
            {userSessions.length}
          </div>
          <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1">
            Targeting {currentUser.targetRole}
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-medium mb-2">
            <span>Average Score Across Sessions</span>
            <TrendingUp className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white">
            {avgScore} <span className="text-xs font-normal text-slate-400">/ 10</span>
          </div>
          <p className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1 font-medium">
            Baseline across all difficulty tiers
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-medium mb-2">
            <span>Highest Score Achieved</span>
            <Award className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white">
            {highestScore} <span className="text-xs font-normal text-slate-400">/ 10</span>
          </div>
          <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1">
            Personal best bar raiser benchmark
          </p>
        </div>
      </div>

      {/* Visual Score Progression Trend */}
      {userSessions.length > 1 && (
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-indigo-500" />
              Score Progression Trend
            </h4>
            <span className="text-[11px] text-slate-500 dark:text-slate-400">
              Recent → Oldest
            </span>
          </div>

          <div className="h-32 flex items-end gap-3 pt-4 px-2">
            {userSessions.slice(0, 10).map((session, idx) => {
              const heightPct = Math.max((session.overallScore / 10) * 100, 15);
              return (
                <div key={session.id} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end group">
                  <span className="text-[10px] font-bold text-slate-600 dark:text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity">
                    {session.overallScore}
                  </span>
                  <div
                    style={{ height: `${heightPct}%` }}
                    className={`w-full rounded-t-lg transition-all ${
                      session.overallScore >= 8
                        ? 'bg-emerald-500 group-hover:bg-emerald-600'
                        : session.overallScore >= 6
                        ? 'bg-indigo-500 group-hover:bg-indigo-600'
                        : 'bg-amber-500 group-hover:bg-amber-600'
                    }`}
                  ></div>
                  <span className="text-[9px] text-slate-400 truncate max-w-full">
                    #{userSessions.length - idx}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Filter and Session List */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xs space-y-6">
        
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-400" />
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
              Filter by Difficulty:
            </span>
            <div className="flex gap-1.5">
              {['All', 'Easy', 'Medium', 'Hard'].map((diff) => (
                <button
                  key={diff}
                  onClick={() => setFilterDifficulty(diff)}
                  className={`text-xs px-3 py-1 rounded-lg transition-all ${
                    filterDifficulty === diff
                      ? 'bg-indigo-600 text-white font-semibold shadow-xs'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {diff}
                </button>
              ))}
            </div>
          </div>

          <span className="text-xs text-slate-400">
            Showing {filteredSessions.length} of {userSessions.length} recorded sessions
          </span>
        </div>

        {filteredSessions.length === 0 ? (
          <div className="text-center py-12 space-y-4">
            <div className="inline-flex p-3 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-500">
              <History className="w-8 h-8" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                No Interview Sessions Found
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto mt-1">
                You haven't completed any mock interviews under this filter yet. Practice your first session to build your portfolio!
              </p>
            </div>
            <button
              onClick={() => setCurrentTab('setup')}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-500/20"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Start New Interview</span>
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredSessions.map((session) => (
              <div
                key={session.id}
                className="p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 hover:border-indigo-400 dark:hover:border-indigo-600 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
              >
                <div className="flex items-start sm:items-center gap-4">
                  <div className="flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white font-extrabold text-lg shadow-xs shrink-0">
                    {session.overallScore}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                        {session.targetRole}
                      </h4>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                        session.difficulty === 'Hard' ? 'bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300' :
                        session.difficulty === 'Medium' ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300' :
                        'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                      }`}>
                        {session.difficulty}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {session.questions.length} questions • Completed on {new Date(session.completedAt).toLocaleDateString()} at {new Date(session.completedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                  <button
                    onClick={() => viewPastSession(session)}
                    className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 transition-colors"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Review Q&A</span>
                  </button>

                  <button
                    onClick={() => {
                      if (window.confirm('Delete this interview session record?')) {
                        deleteSession(session.id);
                      }
                    }}
                    className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                    title="Delete session"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

      </div>
    </div>
  );
};
